"use server";

import { db } from "@/db";
import {
    orders,
    orderItems,
    orderCounters,
    orderDiscounts,
    coupons,
    couponBranchAllocations,
    tenantSettings,
    menuItems,
    menuCategories,
    staff,
    restaurantTables,
    tableReservations,
    deliveries,
    payments,
    ingredients,
    recipeIngredients,
    stockMovements,
    notifications,
} from "@/db/schema";
import { getSupabaseServerClient } from "@/lib/supabase";
import { eq, and, inArray, asc, sql, gte } from "drizzle-orm";
import type { Order, OrderStatus, OrderType, PaymentMethod } from "@/types";
import { hasPermission } from "@/types/staff";
import { RESTAURANT_CONFIG } from "@/config/restaurant";
import { logAudit } from "@/lib/audit";
import { getOfflineRef } from "@/features/orders/lib/printKitchenTicket";
import { broadcastChange } from "@/lib/realtime/broadcast";
import { createNotification } from "../notifications/actions";
import { PaymentService } from "@/lib/payments/PaymentService";

// ─── Input shape ────────────────────────────────────────────────────────

export interface CreateOrderItemInput {
    menuItemId: string;
    variantId?: string;
    modifierOptionIds: string[];
    quantity: number;
    notes?: string;
}

export interface CreateOrderInput {
    orderType: OrderType;
    tableId?: string;
    customerPhone?: string;
    deliveryAddress?: string;
    couponId?: string;
    notes?: string;
    items: CreateOrderItemInput[];
}

// ─── Shared auth helper (same pattern as menu actions) ────────────────

async function getCurrentStaff() {
    const supabase = await getSupabaseServerClient();
    const {
        data: { user },
    } = await supabase.auth.getUser();
    if (!user) return { ok: false as const, error: "Not authenticated." };

    const currentStaffRow = await db.query.staff.findFirst({
        where: eq(staff.id, user.id),
    });
    if (!currentStaffRow) return { ok: false as const, error: "Staff record not found." };

    return { ok: true as const, staff: currentStaffRow };
}

function buildOrderResponse(
    order: typeof orders.$inferSelect,
    items: (typeof orderItems.$inferSelect)[],
    tableNumber?: string,
    discounts: (typeof orderDiscounts.$inferSelect)[] = []
): Order {
    return {
        id: order.id,
        orderNumber: order.orderNumber,
        branchId: order.branchId,
        tableId: order.tableId ?? undefined,
        customerPhone: order.customerPhone ?? undefined,
        orderType: order.orderType,
        status: order.status,
        tableNumber,
        wasOfflineOrder: order.wasOfflineOrder,
        offlineRef: order.wasOfflineOrder && order.idempotencyKey ? getOfflineRef(order.idempotencyKey) : undefined,
        items: items.map((i) => ({
            id: i.id,
            orderId: i.orderId,
            menuItemId: i.menuItemId,
            menuItemName: i.menuItemName,
            menuItemImage: i.menuItemImage ?? undefined,
            categoryId: i.categoryId,
            categoryName: i.categoryName,
            quantity: i.quantity,
            unitPrice: i.unitPrice,
            selectedVariant: i.selectedVariant ?? undefined,
            selectedModifiers: i.selectedModifiers,
            itemTotal: i.itemTotal,
            notes: i.notes ?? undefined,
            status: i.status,
            createdAt: i.createdAt.toISOString(),
        })),
        subtotal: order.subtotal,
        discounts: discounts.map((d) => ({
            id: d.id,
            name: d.name,
            type: d.type,
            value: d.value,
            appliedAmount: d.appliedAmount,
            appliedBy: d.appliedBy,
            appliedByName: d.appliedByName,
        })),
        totalDiscount: order.totalDiscount,
        deliveryFee: order.deliveryFee,
        total: order.total,
        paymentStatus: order.paymentStatus,
        payments: [],
        totalPaid: order.totalPaid,
        balance: order.total - order.totalPaid,
        deliveryAddress: order.deliveryAddress ?? undefined,
        notes: order.notes ?? undefined,
        staffId: order.staffId,
        staffName: order.staffName,
        createdAt: order.createdAt.toISOString(),
        updatedAt: order.updatedAt.toISOString(),
        billPrintedAt: order.billPrintedAt?.toISOString(),
    };
}

// ─── Create Order ───────────────────────────────────────────────────────

export async function createOrderAction(
    input: CreateOrderInput,
    targetBranchId?: string,
    idempotencyKey?: string,
    queuedAt?: Date,
    wasOfflineOrder: boolean = false
): Promise<{ success: true; order: Order } | { success?: undefined; error: string }> {
    const auth = await getCurrentStaff();
    if (!auth.ok) return { error: auth.error };
    const { staff: currentStaffRow } = auth;

    if (!["STAFF", "ADMIN", "SUPER_ADMIN"].includes(currentStaffRow.role)) {
        return { error: "You don't have permission to create orders." };
    }

    // Resolve branch — STAFF/ADMIN locked to their own, SUPER_ADMIN must specify
    let branchId: string;
    if (currentStaffRow.role === "SUPER_ADMIN") {
        if (!targetBranchId) {
            return { error: "Select a branch before creating an order." };
        }
        branchId = targetBranchId;
    } else {
        if (!currentStaffRow.branchId) {
            return { error: "Your account has no branch assigned." };
        }
        branchId = currentStaffRow.branchId;
    }

    if (input.items.length === 0) {
        return { error: "Cannot create an order with no items." };
    }

    const timerId = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    console.time(`[createOrderAction] total ${timerId}`);

    // Idempotency check — if this exact order attempt already succeeded
    // (e.g. the client timed out waiting but the request actually landed,
    // or a background retry from an offline client duplicated the call),
    // return the existing order instead of creating a duplicate.
    if (idempotencyKey) {
        const existing = await db.query.orders.findFirst({
            where: and(
                eq(orders.tenantId, currentStaffRow.tenantId),
                eq(orders.idempotencyKey, idempotencyKey)
            ),
            with: { items: true, table: true, discounts: true },
        });
        if (existing) {
            return {
                success: true,
                order: buildOrderResponse(existing, existing.items, existing.table?.tableNumber, existing.discounts),
            };
        }
    }

    try {
        console.time(`[createOrderAction] transaction ${timerId}`);
        const result = await db.transaction(async (tx) => {
            // ── 1. Fetch real menu items for every line in the cart ──────
            // Runs in parallel with the table lookup below — independent
            // queries, no reason to wait for one before starting the other.
            const menuItemIds = [...new Set(input.items.map((i) => i.menuItemId))];
            const [realMenuItems, preloadedTable] = await Promise.all([
                tx.query.menuItems.findMany({
                    where: and(
                        inArray(menuItems.id, menuItemIds),
                        eq(menuItems.tenantId, currentStaffRow.tenantId),
                        eq(menuItems.branchId, branchId)
                    ),
                    with: {
                        variants: true,
                        modifierGroups: { with: { options: true } },
                    },
                }),
                input.tableId
                    ? tx.query.restaurantTables.findFirst({
                        where: eq(restaurantTables.id, input.tableId),
                    })
                    : Promise.resolve(null),
            ]);

            const menuItemMap = new Map(realMenuItems.map((m) => [m.id, m]));

            // ── 2. Build each order item from real DB prices ─────────────
            const builtItems = input.items.map((line) => {
                const menuItem = menuItemMap.get(line.menuItemId);
                if (!menuItem) {
                    throw new Error(`Menu item not found or unavailable: ${line.menuItemId}`);
                }
                if (menuItem.status !== "available") {
                    throw new Error(`"${menuItem.name}" is not currently available.`);
                }

                let unitPrice = menuItem.basePrice;
                let selectedVariant = null;

                if (line.variantId) {
                    const variant = menuItem.variants.find((v) => v.id === line.variantId);
                    if (!variant) throw new Error(`Invalid variant for "${menuItem.name}".`);
                    unitPrice = variant.price;
                    selectedVariant = {
                        variantId: variant.id,
                        variantName: variant.name,
                        priceAdjustment: 0,
                    };
                }

                const allOptions = menuItem.modifierGroups.flatMap((g) =>
                    g.options.map((o) => ({ ...o, groupId: g.id, groupName: g.name }))
                );
                const selectedModifiers = line.modifierOptionIds.map((optId) => {
                    const opt = allOptions.find((o) => o.id === optId);
                    if (!opt) throw new Error(`Invalid modifier option for "${menuItem.name}".`);
                    unitPrice += opt.priceAdjustment;
                    return {
                        groupId: opt.groupId,
                        groupName: opt.groupName,
                        optionId: opt.id,
                        optionName: opt.name,
                        priceAdjustment: opt.priceAdjustment,
                    };
                });

                const itemTotal = unitPrice * line.quantity;

                return {
                    menuItemId: menuItem.id,
                    menuItemName: menuItem.name,
                    menuItemImage: menuItem.image ?? null,
                    categoryId: menuItem.categoryId,
                    categoryName: "", // filled below
                    quantity: line.quantity,
                    unitPrice,
                    itemTotal,
                    selectedVariant,
                    selectedModifiers,
                    notes: line.notes ?? null,
                };
            });

            // ── 3. Look up category names for the snapshot ───────────────
            const categoryIds = [...new Set(builtItems.map((i) => i.categoryId))];
            const categories = await tx.query.menuCategories.findMany({
                where: inArray(menuCategories.id, categoryIds),
            });
            const categoryNameMap = new Map(categories.map((c) => [c.id, c.name]));
            for (const item of builtItems) {
                item.categoryName = categoryNameMap.get(item.categoryId) ?? "Uncategorized";
            }

            // ── 4. Compute totals server-side ─────────────────────────────
            const subtotal = builtItems.reduce((sum, i) => sum + i.itemTotal, 0);

            // Coupon validation happens entirely server-side, inside the
            // transaction, against live data — the client only ever sends
            // a couponId, never a discount amount. Fetching the coupon here
            // (not before the transaction) means its usesCount check and
            // later increment happen under the same transaction, closing
            // the window for two concurrent orders to both redeem the last
            // use of a maxUses-limited coupon.
            let appliedCoupon: typeof coupons.$inferSelect | null = null;
            let totalDiscount = 0;

            if (input.couponId) {
                const now = new Date();

                const settings = await tx.query.tenantSettings.findFirst({
                    where: eq(tenantSettings.tenantId, currentStaffRow.tenantId),
                });
                if (settings && settings.posAllowDiscounts === false) {
                    throw new Error("Discounts are currently disabled for this restaurant.");
                }

                const coupon = await tx.query.coupons.findFirst({
                    where: and(
                        eq(coupons.id, input.couponId),
                        eq(coupons.tenantId, currentStaffRow.tenantId)
                    ),
                });

                if (!coupon) {
                    throw new Error("Coupon not found.");
                }
                if (!coupon.isActive) {
                    throw new Error(`Coupon "${coupon.name}" is no longer active.`);
                }
                if (coupon.validFrom && coupon.validFrom > now) {
                    throw new Error(`Coupon "${coupon.name}" is not valid yet.`);
                }
                if (coupon.validTo && coupon.validTo < now) {
                    throw new Error(`Coupon "${coupon.name}" has expired.`);
                }
                if (coupon.maxUses !== null && coupon.usesCount >= coupon.maxUses) {
                    throw new Error(`Coupon "${coupon.name}" has reached its usage limit.`);
                }
                if (coupon.branchIds && !coupon.branchIds.includes(branchId)) {
                    throw new Error(`Coupon "${coupon.name}" is not valid at this branch.`);
                }

                if (coupon.menuItemIds || coupon.categoryIds) {
                    const eligibleSubtotal = builtItems.reduce((sum, i) => {
                        const itemEligible =
                            (coupon.menuItemIds?.includes(i.menuItemId) ?? false) ||
                            (coupon.categoryIds?.includes(i.categoryId) ?? false);
                        return itemEligible ? sum + i.itemTotal : sum;
                    }, 0);
                    if (eligibleSubtotal === 0) {
                        throw new Error(`Coupon "${coupon.name}" doesn't apply to any items in this order.`);
                    }
                    totalDiscount =
                        coupon.discountType === "percentage"
                            ? Math.round(eligibleSubtotal * (Math.min(coupon.discountValue, 100) / 100))
                            : Math.min(coupon.discountValue, eligibleSubtotal);
                } else {
                    totalDiscount =
                        coupon.discountType === "percentage"
                            ? Math.round(subtotal * (Math.min(coupon.discountValue, 100) / 100))
                            : Math.min(coupon.discountValue, subtotal);
                }

                appliedCoupon = coupon;
            }

            const deliveryFee = input.orderType === "delivery" ? RESTAURANT_CONFIG.defaultDeliveryFee : 0;
            const total = subtotal - totalDiscount + deliveryFee;

            // ── 5. Atomically get next order number for this branch ──────
            // First order for a branch: no row yet, insert starting at 2 —
            // meaning this order is assigned number 1.
            // Every order after: row exists, atomically bump nextNumber by 1
            // and use the value it had *before* the bump. The increment
            // happens as a single UPDATE ... RETURNING under Postgres's own
            // row lock, so two staff submitting orders at the same instant
            // can never receive the same number.
            const [counter] = await tx
                .insert(orderCounters)
                .values({ branchId, tenantId: currentStaffRow.tenantId, nextNumber: 2 })
                .onConflictDoUpdate({
                    target: orderCounters.branchId,
                    set: { nextNumber: sql`${orderCounters.nextNumber} + 1` },
                })
                .returning();

            const orderNumber = `ORD-${String(counter.nextNumber - 1).padStart(4, "0")}`;

            let tableNumber: string | undefined;
            if (input.tableId) {
                tableNumber = preloadedTable?.tableNumber;

                // Independent of each other — run together instead of one after another.
                await Promise.all([
                    tx
                        .update(restaurantTables)
                        .set({ status: "occupied", updatedAt: new Date() })
                        .where(eq(restaurantTables.id, input.tableId)),
                    // If this table had an open reservation, seating an order
                    // against it resolves that reservation automatically —
                    // staff aren't required to hit a separate "seat" button.
                    tx
                        .update(tableReservations)
                        .set({ status: "seated", updatedAt: new Date() })
                        .where(
                            and(
                                eq(tableReservations.tableId, input.tableId),
                                inArray(tableReservations.status, ["pending", "confirmed"])
                            )
                        ),
                ]);
            }

            // ── 6. Insert order + items ────────────────────────────────
            const [createdOrder] = await tx
                .insert(orders)
                .values({
                    tenantId: currentStaffRow.tenantId,
                    branchId,
                    orderNumber,
                    tableId: input.tableId ?? null,
                    customerPhone: input.customerPhone ?? null,
                    orderType: input.orderType,
                    status: "pending",
                    subtotal,
                    totalDiscount,
                    deliveryFee,
                    total,
                    // Balance starts as the full total — nothing paid yet.
                    // Without this, a fresh order's balance sits at 0 (the
                    // column default) until its first payment recalculates
                    // it, which broke split/deposit payments taken before
                    // any other payment exists on the order.
                    balance: total,
                    deliveryAddress: input.deliveryAddress ?? null,
                    notes: input.notes ?? null,
                    staffId: currentStaffRow.id,
                    staffName: `${currentStaffRow.firstName} ${currentStaffRow.lastName}`,
                    idempotencyKey: idempotencyKey ?? null,
                    wasOfflineOrder,
                    // Offline orders pass their true placement time so the
                    // kitchen ticket and Orders page reflect when the order
                    // actually happened, not when it happened to sync.
                    ...(queuedAt ? { createdAt: queuedAt } : {}),
                })
                .returning();

            if (input.orderType === "delivery") {
                await tx.insert(deliveries).values({
                    tenantId: currentStaffRow.tenantId,
                    branchId,
                    orderId: createdOrder.id,
                    riderId: null,
                    status: "unassigned",
                    deliveryAddress: {
                        label: null,
                        street: input.deliveryAddress ?? "",
                        area: "",
                        city: "",
                        instructions: null,
                    },
                    deliveryFee,
                });
            }

            const insertedItems = await tx
                .insert(orderItems)
                .values(
                    builtItems.map((i) => ({
                        tenantId: currentStaffRow.tenantId,
                        orderId: createdOrder.id,
                        menuItemId: i.menuItemId,
                        menuItemName: i.menuItemName,
                        menuItemImage: i.menuItemImage,
                        categoryId: i.categoryId,
                        categoryName: i.categoryName,
                        quantity: i.quantity,
                        unitPrice: i.unitPrice,
                        itemTotal: i.itemTotal,
                        selectedVariant: i.selectedVariant,
                        selectedModifiers: i.selectedModifiers,
                        notes: i.notes,
                    }))
                )
                .returning();

            let insertedDiscounts: (typeof orderDiscounts.$inferSelect)[] = [];
            // Only ever populated for the overuse check below — two offline
            // terminals can each independently allow the same coupon, since
            // neither can see the other's usage while disconnected. Can't be
            // prevented, only caught once both sync and this number is real.
            let updatedAllocation: typeof couponBranchAllocations.$inferSelect | undefined;
            let appliedCouponSnapshot: { id: string; name: string } | null = null;
            if (appliedCoupon) {
                appliedCouponSnapshot = { id: appliedCoupon.id, name: appliedCoupon.name };
                const [discountRows, , allocationRows] = await Promise.all([
                    tx
                        .insert(orderDiscounts)
                        .values({
                            tenantId: currentStaffRow.tenantId,
                            orderId: createdOrder.id,
                            name: appliedCoupon.name,
                            type: appliedCoupon.discountType,
                            value: appliedCoupon.discountValue,
                            appliedAmount: totalDiscount,
                            appliedBy: currentStaffRow.id,
                            appliedByName: `${currentStaffRow.firstName} ${currentStaffRow.lastName}`,
                            couponId: appliedCoupon.id,
                        })
                        .returning(),
                    tx
                        .update(coupons)
                        .set({ usesCount: sql`${coupons.usesCount} + 1`, updatedAt: new Date() })
                        .where(eq(coupons.id, appliedCoupon.id)),
                    // No-ops harmlessly if this coupon has no per-branch
                    // allocation row (single-branch or uncapped coupons).
                    tx
                        .update(couponBranchAllocations)
                        .set({ usedCount: sql`${couponBranchAllocations.usedCount} + 1` })
                        .where(
                            and(
                                eq(couponBranchAllocations.couponId, appliedCoupon.id),
                                eq(couponBranchAllocations.branchId, branchId)
                            )
                        )
                        .returning(),
                ]);
                insertedDiscounts = discountRows;
                updatedAllocation = allocationRows[0];
            }

            return {
                order: createdOrder,
                items: insertedItems,
                discounts: insertedDiscounts,
                tableNumber,
                updatedAllocation,
                appliedCouponSnapshot,
            };
        });
        console.timeEnd(`[createOrderAction] transaction ${timerId}`);

        console.time(`[createOrderAction] audit+broadcast ${timerId}`);
        const auditPromises = [
            logAudit(db, currentStaffRow, "order", result.order.id, "create", {
                branchId: result.order.branchId,
                newValue: {
                    orderNumber: result.order.orderNumber,
                    orderType: result.order.orderType,
                    total: result.order.total,
                    tableNumber: result.tableNumber,
                },
            }),
        ];

        const broadcastPromises = [
            broadcastChange(result.order.branchId, "orders"),
            createNotification({
                tenantId: result.order.tenantId,
                branchId: result.order.branchId,
                type: "order_new",
                title: "New order",
                message: `Order ${result.order.orderNumber} placed (${result.order.orderType}).`,
                resourceType: "order",
                resourceId: result.order.id,
            }),
        ];
        if (input.tableId) {
            broadcastPromises.push(broadcastChange(result.order.branchId, "tables"));
        }
        if (result.appliedCouponSnapshot) {
            // Lets every other POS terminal at this branch refresh its
            // cached "remaining uses" number right away, instead of only
            // finding out next time that terminal happens to refetch.
            broadcastPromises.push(broadcastChange(result.order.branchId, "coupons"));
        }

        // Two offline terminals can each independently allow the same
        // coupon past its real remaining count, since neither can see the
        // other's usage while disconnected — this can only be caught here,
        // once a synced order pushes the real count past the branch's
        // allocation. Never blocks the order (it already happened); just
        // flags it for a person to review, same pattern as offline
        // table/rider conflicts.
        if (
            wasOfflineOrder &&
            result.updatedAllocation &&
            result.appliedCouponSnapshot &&
            result.updatedAllocation.usedCount > result.updatedAllocation.allocatedUses
        ) {
            auditPromises.push(
                logAudit(db, currentStaffRow, "coupon", result.appliedCouponSnapshot.id, "update", {
                    branchId: result.order.branchId,
                    description: `Coupon "${result.appliedCouponSnapshot.name}" over-redeemed at this branch after an offline sync — ${result.updatedAllocation.usedCount}/${result.updatedAllocation.allocatedUses} used. Likely two offline terminals both allowed it independently.`,
                })
            );
            broadcastPromises.push(
                createNotification({
                    tenantId: result.order.tenantId,
                    branchId: result.order.branchId,
                    type: "coupon_overuse",
                    title: "Coupon over-redeemed",
                    message: `"${result.appliedCouponSnapshot.name}" was used ${result.updatedAllocation.usedCount} times at this branch (allowed: ${result.updatedAllocation.allocatedUses}) — likely from multiple offline terminals syncing independently.`,
                    resourceType: "coupon",
                    resourceId: result.appliedCouponSnapshot.id,
                })
            );
        }

        await Promise.all([...auditPromises, ...broadcastPromises]);

        console.timeEnd(`[createOrderAction] audit+broadcast ${timerId}`);
        console.timeEnd(`[createOrderAction] total ${timerId}`);

        return {
            success: true,
            order: buildOrderResponse(result.order, result.items, result.tableNumber, result.discounts),
        };
    } catch (err) {
        const pgErr = err as { code?: string };
        if (idempotencyKey && pgErr.code === "23505") {
            // Concurrent duplicate — another request with the same
            // idempotency key won the race and inserted first, after our
            // pre-check above already passed. This is the safety net for
            // that narrow window, not the primary defense.
            const existing = await db.query.orders.findFirst({
                where: and(
                    eq(orders.tenantId, currentStaffRow.tenantId),
                    eq(orders.idempotencyKey, idempotencyKey)
                ),
                with: { items: true, table: true, discounts: true },
            });
            if (existing) {
                return {
                    success: true,
                    order: buildOrderResponse(existing, existing.items, existing.table?.tableNumber, existing.discounts),
                };
            }
        }
        return { error: `Failed to create order: ${(err as Error).message}` };
    }
}

// ─── Read Orders ─────────────────────────────────────────────────────────

export interface GetOrdersFilters {
    statuses?: OrderStatus[];
    dateFrom?: string; // ISO string
    dateTo?: string; // ISO string
}

const MAX_ORDERS_RETURNED = 500;

export async function getOrdersAction(
    overrideBranchId?: string,
    filters?: GetOrdersFilters
): Promise<{ data: Order[]; error?: undefined } | { data: null; error: string }> {
    const auth = await getCurrentStaff();
    if (!auth.ok) return { data: null, error: auth.error };
    const { staff: currentStaffRow } = auth;

    const isBranchLocked = currentStaffRow.role === "ADMIN" || currentStaffRow.role === "STAFF";
    if (isBranchLocked && !currentStaffRow.branchId) {
        return { data: null, error: "Your account has no branch assigned." };
    }

    const tenantId = currentStaffRow.tenantId;
    const branchId = isBranchLocked ? currentStaffRow.branchId! : overrideBranchId;

    const rows = await db.query.orders.findMany({
        where: (o, { eq: eqOp, and: andOp, inArray: inArrayOp, gte: gteOp, lte: lteOp }) =>
            andOp(
                eqOp(o.tenantId, tenantId),
                branchId ? eqOp(o.branchId, branchId) : undefined,
                filters?.statuses?.length ? inArrayOp(o.status, filters.statuses) : undefined,
                filters?.dateFrom ? gteOp(o.createdAt, new Date(filters.dateFrom)) : undefined,
                filters?.dateTo ? lteOp(o.createdAt, new Date(filters.dateTo)) : undefined
            ),
        with: {
            items: true,
            discounts: true,
            payments: true,
            table: true,
        },
        orderBy: (o, { desc }) => [desc(o.createdAt)],
        limit: MAX_ORDERS_RETURNED,
    });

    const data: Order[] = rows.map((o) => ({
        id: o.id,
        orderNumber: o.orderNumber,
        branchId: o.branchId,
        tableId: o.tableId ?? undefined,
        tableNumber: o.table?.tableNumber,
        customerPhone: o.customerPhone ?? undefined,
        orderType: o.orderType,
        status: o.status,
        wasOfflineOrder: o.wasOfflineOrder,
        offlineRef: o.wasOfflineOrder && o.idempotencyKey ? getOfflineRef(o.idempotencyKey) : undefined,
        items: o.items.map((i) => ({
            id: i.id,
            orderId: i.orderId,
            menuItemId: i.menuItemId,
            menuItemName: i.menuItemName,
            menuItemImage: i.menuItemImage ?? undefined,
            categoryId: i.categoryId,
            categoryName: i.categoryName,
            quantity: i.quantity,
            unitPrice: i.unitPrice,
            selectedVariant: i.selectedVariant ?? undefined,
            selectedModifiers: i.selectedModifiers,
            itemTotal: i.itemTotal,
            notes: i.notes ?? undefined,
            status: i.status,
            createdAt: i.createdAt.toISOString(),
        })),
        subtotal: o.subtotal,
        discounts: o.discounts.map((d) => ({
            id: d.id,
            name: d.name,
            type: d.type,
            value: d.value,
            appliedAmount: d.appliedAmount,
            appliedBy: d.appliedBy,
            appliedByName: d.appliedByName,
        })),
        totalDiscount: o.totalDiscount,
        deliveryFee: o.deliveryFee,
        total: o.total,
        paymentStatus: o.paymentStatus,
        payments: o.payments.map((p) => ({
            id: p.id,
            orderId: p.orderId,
            method: p.method,
            amount: p.amount,
            reference: p.reference ?? undefined,
            processedAt: p.processedAt.toISOString(),
            processedBy: p.processedBy,
            processedByName: p.processedByName,
            provider: p.provider,
            status: p.status,
        })),
        totalPaid: o.totalPaid,
        balance: o.balance,
        deliveryAddress: o.deliveryAddress ?? undefined,
        estimatedDeliveryMinutes: o.estimatedDeliveryMinutes ?? undefined,
        notes: o.notes ?? undefined,
        staffId: o.staffId,
        staffName: o.staffName,
        createdAt: o.createdAt.toISOString(),
        updatedAt: o.updatedAt.toISOString(),
        completedAt: o.completedAt?.toISOString(),
        billPrintedAt: o.billPrintedAt?.toISOString(),
    }));

    return { data };
}

// ─── Get Single Order ────────────────────────────────────────────────────

export async function getOrderByIdAction(
    orderId: string
): Promise<{ data: Order; error?: undefined } | { data: null; error: string }> {
    const auth = await getCurrentStaff();
    if (!auth.ok) return { data: null, error: auth.error };
    const { staff: currentStaffRow } = auth;

    const row = await db.query.orders.findFirst({
        where: eq(orders.id, orderId),
        with: {
            items: true,
            discounts: true,
            payments: true,
            table: true,
            rider: true,
            delivery: true,
        },
    });

    if (!row || row.tenantId !== currentStaffRow.tenantId) {
        return { data: null, error: "Order not found." };
    }
    if (currentStaffRow.role !== "SUPER_ADMIN" && row.branchId !== currentStaffRow.branchId) {
        return { data: null, error: "You can only view your own branch's orders." };
    }

    return {
        data: {
            id: row.id,
            orderNumber: row.orderNumber,
            branchId: row.branchId,
            tableId: row.tableId ?? undefined,
            tableNumber: row.table?.tableNumber,
            riderId: row.riderId ?? undefined,
            riderName: row.rider ? `${row.rider.firstName} ${row.rider.lastName}` : undefined,
            deliveryStatus: row.delivery?.status ?? undefined,
            customerPhone: row.customerPhone ?? undefined,
            orderType: row.orderType,
            status: row.status,
            wasOfflineOrder: row.wasOfflineOrder,
            offlineRef: row.wasOfflineOrder && row.idempotencyKey ? getOfflineRef(row.idempotencyKey) : undefined,
            items: row.items.map((i) => ({
                id: i.id,
                orderId: i.orderId,
                menuItemId: i.menuItemId,
                menuItemName: i.menuItemName,
                menuItemImage: i.menuItemImage ?? undefined,
                categoryId: i.categoryId,
                categoryName: i.categoryName,
                quantity: i.quantity,
                unitPrice: i.unitPrice,
                selectedVariant: i.selectedVariant ?? undefined,
                selectedModifiers: i.selectedModifiers,
                itemTotal: i.itemTotal,
                notes: i.notes ?? undefined,
                status: i.status,
                createdAt: i.createdAt.toISOString(),
            })),
            subtotal: row.subtotal,
            discounts: row.discounts.map((d) => ({
                id: d.id,
                name: d.name,
                type: d.type,
                value: d.value,
                appliedAmount: d.appliedAmount,
                appliedBy: d.appliedBy,
                appliedByName: d.appliedByName,
            })),
            totalDiscount: row.totalDiscount,
            deliveryFee: row.deliveryFee,
            total: row.total,
            paymentStatus: row.paymentStatus,
            payments: row.payments.map((p) => ({
                id: p.id,
                orderId: p.orderId,
                method: p.method,
                amount: p.amount,
                reference: p.reference ?? undefined,
                processedAt: p.processedAt.toISOString(),
                processedBy: p.processedBy,
                processedByName: p.processedByName,
                provider: p.provider,
                status: p.status,
            })),
            totalPaid: row.totalPaid,
            balance: row.balance,
            deliveryAddress: row.deliveryAddress ?? undefined,
            estimatedDeliveryMinutes: row.estimatedDeliveryMinutes ?? undefined,
            notes: row.notes ?? undefined,
            staffId: row.staffId,
            staffName: row.staffName,
            createdAt: row.createdAt.toISOString(),
            updatedAt: row.updatedAt.toISOString(),
            completedAt: row.completedAt?.toISOString(),
            billPrintedAt: row.billPrintedAt?.toISOString(),
        },
    };
}

// ─── Confirm Order (kitchen ticket) ─────────────────────────────────────

export async function confirmOrderAction(
    orderId: string
): Promise<{ success: true } | { success?: undefined; error: string }> {
    const auth = await getCurrentStaff();
    if (!auth.ok) return { error: auth.error };
    const { staff: currentStaffRow } = auth;

    const target = await db.query.orders.findFirst({ where: eq(orders.id, orderId) });
    if (!target || target.tenantId !== currentStaffRow.tenantId) {
        return { error: "Order not found." };
    }
    if (currentStaffRow.role !== "SUPER_ADMIN" && target.branchId !== currentStaffRow.branchId) {
        return { error: "You can only manage your own branch's orders." };
    }
    if (target.status !== "pending") {
        return { error: `Cannot confirm an order that is already "${target.status}".` };
    }

    await db.update(orders).set({ status: "confirmed", updatedAt: new Date() }).where(eq(orders.id, orderId));

    await logAudit(db, currentStaffRow, "order", orderId, "status_change", {
        branchId: target.branchId,
        oldValue: { status: target.status },
        newValue: { status: "confirmed", orderNumber: target.orderNumber },
    });

    await broadcastChange(target.branchId, "orders");

    return { success: true };
}

// ─── Mark Bill Printed ──────────────────────────────────────────────────

// Called once the delivery bill has actually been printed. Persisted in
// the DB (not just component state) so re-opening the order — even in a
// fresh session, even on a different device — never re-triggers the
// auto-print popup for an order that's already been printed once.
export async function markBillPrintedAction(
    orderId: string
): Promise<{ success: true } | { success?: undefined; error: string }> {
    const auth = await getCurrentStaff();
    if (!auth.ok) return { error: auth.error };
    const { staff: currentStaffRow } = auth;

    const target = await db.query.orders.findFirst({ where: eq(orders.id, orderId) });
    if (!target || target.tenantId !== currentStaffRow.tenantId) {
        return { error: "Order not found." };
    }
    if (currentStaffRow.role !== "SUPER_ADMIN" && target.branchId !== currentStaffRow.branchId) {
        return { error: "You can only manage your own branch's orders." };
    }

    await db
        .update(orders)
        .set({ billPrintedAt: new Date() })
        .where(eq(orders.id, orderId));

    return { success: true };
}

// ─── Inventory auto-deduction (runs inside completeBillAction's tx) ─────

type QueryClient = Parameters<Parameters<typeof db.transaction>[0]>[0] | typeof db;

const round3 = (n: number) => Math.round(n * 1000) / 1000;

/**
 * Deducts recipe ingredients for every item on an order once it's actually
 * completed. Idempotent (skips if "sale" movements already exist for this
 * order — guards the offline duplicate-completion path). Sale deductions
 * are allowed to push stock negative and must never block/fail the order.
 * Menu items with no recipe deduct nothing. Modifiers have no recipe
 * support yet.
 */
interface LowStockAlert {
    branchId: string;
    ingredientId: string;
    ingredientName: string;
    currentStock: number;
    unit: string;
}

async function deductInventoryForCompletedOrder(
    tx: QueryClient,
    params: { tenantId: string; branchId: string; orderId: string; staffId: string; staffName: string }
): Promise<LowStockAlert[]> {
    const lowStockAlerts: LowStockAlert[] = [];

    const already = await tx.query.stockMovements.findFirst({
        where: and(eq(stockMovements.orderId, params.orderId), eq(stockMovements.reason, "sale")),
    });
    if (already) return lowStockAlerts;

    const items = await tx.query.orderItems.findMany({
        where: eq(orderItems.orderId, params.orderId),
    });
    if (items.length === 0) return lowStockAlerts;

    const menuItemIds = [...new Set(items.map((i) => i.menuItemId))];

    const recipeRows = await tx.query.recipeIngredients.findMany({
        where: and(
            inArray(recipeIngredients.menuItemId, menuItemIds),
            eq(recipeIngredients.tenantId, params.tenantId)
        ),
    });
    if (recipeRows.length === 0) return lowStockAlerts;

    const recipeByMenuItem = new Map<string, typeof recipeRows>();
    for (const r of recipeRows) {
        const list = recipeByMenuItem.get(r.menuItemId) ?? [];
        list.push(r);
        recipeByMenuItem.set(r.menuItemId, list);
    }

    // Aggregate quantity needed per ingredient across the whole order first.
    const usage = new Map<string, number>();
    for (const item of items) {
        const lines = recipeByMenuItem.get(item.menuItemId);
        if (!lines) continue;
        const variantId = item.selectedVariant?.variantId ?? null;
        for (const line of lines) {
            // null = applies to every variant; otherwise only the matching one.
            if (line.menuItemVariantId !== null && line.menuItemVariantId !== variantId) continue;
            const qty = round3(line.quantityPerUnit * item.quantity);
            usage.set(line.ingredientId, round3((usage.get(line.ingredientId) ?? 0) + qty));
        }
    }
    if (usage.size === 0) return lowStockAlerts;

    // Lock in a consistent (sorted) order to avoid deadlocks between
    // concurrent completions touching overlapping ingredients.
    const ingredientIds = [...usage.keys()].sort();
    const locked = await tx
        .select()
        .from(ingredients)
        .where(and(inArray(ingredients.id, ingredientIds), eq(ingredients.branchId, params.branchId)))
        .orderBy(asc(ingredients.id))
        .for("update");

    const now = new Date();
    for (const ing of locked) {
        const qtyUsed = usage.get(ing.id);
        if (!qtyUsed) continue;

        const newStock = round3(ing.currentStock - qtyUsed);
        const costImpact = -Math.round(qtyUsed * ing.avgCostPerUnit);
        const wasAlreadyLow =
            ing.lowStockThreshold !== null && ing.currentStock <= ing.lowStockThreshold;
        const isNowLow =
            ing.lowStockThreshold !== null && newStock <= ing.lowStockThreshold;

        await tx
            .update(ingredients)
            .set({ currentStock: newStock, updatedAt: now })
            .where(eq(ingredients.id, ing.id));

        await tx.insert(stockMovements).values({
            tenantId: params.tenantId,
            branchId: ing.branchId,
            ingredientId: ing.id,
            reason: "sale",
            quantityChange: -qtyUsed,
            costImpact,
            orderId: params.orderId,
            createdBy: params.staffId,
            createdByName: params.staffName,
        });

        if (isNowLow) {
            // Notify on first crossing into low stock, and re-notify at
            // most once per 24h while it stays low and unrestocked —
            // never on every single sale once it's already low.
            let shouldAlert = !wasAlreadyLow;
            if (wasAlreadyLow) {
                const dayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
                const recentAlert = await tx.query.notifications.findFirst({
                    where: and(
                        eq(notifications.type, "low_stock"),
                        eq(notifications.resourceType, "ingredient"),
                        eq(notifications.resourceId, ing.id),
                        gte(notifications.createdAt, dayAgo)
                    ),
                });
                shouldAlert = !recentAlert;
            }
            if (shouldAlert) {
                lowStockAlerts.push({
                    branchId: ing.branchId,
                    ingredientId: ing.id,
                    ingredientName: ing.name,
                    currentStock: newStock,
                    unit: ing.unit,
                });
            }
        }
    }

    return lowStockAlerts;
}

// ─── Complete Bill (mark paid) ──────────────────────────────────────────

export async function completeBillAction(
    orderId: string,
    paymentMethod: "cash" | "card" | "jazzcash" | "easypaisa" | "bank_transfer" | "complimentary" = "cash",
    clientPaymentId?: string,
    amount?: number
): Promise<{ success: true; fullyPaid: boolean } | { success?: undefined; error: string }> {
    const auth = await getCurrentStaff();
    if (!auth.ok) return { error: auth.error };
    const { staff: currentStaffRow } = auth;

    const target = await db.query.orders.findFirst({ where: eq(orders.id, orderId) });
    if (!target || target.tenantId !== currentStaffRow.tenantId) {
        return { error: "Order not found." };
    }
    if (currentStaffRow.role !== "SUPER_ADMIN" && target.branchId !== currentStaffRow.branchId) {
        return { error: "You can only manage your own branch's orders." };
    }
    if (target.status === "completed" || target.status === "cancelled") {
        if (target.status === "completed" && clientPaymentId) {
            // Two offline terminals can each independently complete the
            // same order, since neither can see the other while
            // disconnected — offline completion is always a full-balance
            // cash payment (never partial), so if the payment that
            // already completed this order also covered the full total,
            // this is that harmless duplicate, not a real conflict.
            const completingPayment = await db.query.payments.findFirst({
                where: eq(payments.orderId, orderId),
                orderBy: (p, { desc }) => [desc(p.initiatedAt)],
            });
            if (completingPayment && completingPayment.amount === target.total) {
                return { success: true, fullyPaid: true };
            }
            // Doesn't match — a real mismatch, never guess. Flag it for a
            // person instead of silently keeping one side or the other.
            await Promise.all([
                logAudit(db, currentStaffRow, "order", orderId, "update", {
                    branchId: target.branchId,
                    description: `A duplicate offline completion attempt on order ${target.orderNumber} didn't match the amount already recorded (recorded: ${completingPayment?.amount ?? "none found"}, order total: ${target.total}) — needs review.`,
                }),
                createNotification({
                    tenantId: currentStaffRow.tenantId,
                    branchId: target.branchId,
                    type: "order_completion_conflict",
                    title: "Order completion mismatch",
                    message: `Order ${target.orderNumber} was completed with an amount that doesn't match a duplicate offline completion attempt. Please review.`,
                    resourceType: "order",
                    resourceId: orderId,
                }),
            ]);
            return { error: "This order was already completed, but the recorded amount doesn't match — flagged for review." };
        }
        return { error: `Cannot complete an order that is already "${target.status}".` };
    }

    // A clientPaymentId means this call may be a resync of a payment that
    // already succeeded once (offline queue retry) — if a payment with this
    // id already exists, this exact payment already landed, so just report
    // success instead of double-inserting or double-counting totalPaid.
    if (clientPaymentId) {
        const existingPayment = await db.query.payments.findFirst({
            where: (p, { eq: eqOp }) => eqOp(p.clientPaymentId, clientPaymentId),
        });
        if (existingPayment) {
            // By this point target.status is guaranteed not "completed"
            // (the guard above already returned early for that case), so
            // a matching clientPaymentId here means this specific payment
            // was already recorded but didn't fully pay off the order.
            return { success: true, fullyPaid: false };
        }
    }

    const remainingBalance = target.total - target.totalPaid;

    // Already fully paid (e.g. PayFast online payment) but still sitting
    // in the normal order flow — just mark it completed, no new payment.
    if (remainingBalance <= 0) {
        if (target.orderType === "delivery") {
            const delivery = await db.query.deliveries.findFirst({ where: eq(deliveries.orderId, orderId) });
            if (!delivery || delivery.status !== "delivered") {
                return { error: "This delivery hasn't been marked delivered by the rider yet." };
            }
        }

        const now = new Date();
        const lowStockAlerts = await db.transaction(async (tx) => {
            await tx
                .update(orders)
                .set({ status: "completed", completedAt: now, updatedAt: now })
                .where(eq(orders.id, orderId));

            if (target.tableId) {
                await tx
                    .update(restaurantTables)
                    .set({ status: "available", updatedAt: now })
                    .where(eq(restaurantTables.id, target.tableId));
            }

            return deductInventoryForCompletedOrder(tx, {
                tenantId: currentStaffRow.tenantId,
                branchId: target.branchId,
                orderId,
                staffId: currentStaffRow.id,
                staffName: `${currentStaffRow.firstName} ${currentStaffRow.lastName}`,
            });
        });

        await logAudit(db, currentStaffRow, "order", orderId, "status_change", {
            branchId: target.branchId,
            oldValue: { status: target.status },
            newValue: { status: "completed", orderNumber: target.orderNumber },
        });

        await broadcastChange(target.branchId, "orders");
        if (target.tableId) {
            await broadcastChange(target.branchId, "tables");
        }
        for (const alert of lowStockAlerts) {
            await createNotification({
                tenantId: currentStaffRow.tenantId,
                branchId: alert.branchId,
                type: "low_stock",
                title: "Low stock",
                message: `${alert.ingredientName} is low: ${alert.currentStock} ${alert.unit} left.`,
                resourceType: "ingredient",
                resourceId: alert.ingredientId,
            });
        }

        return { success: true, fullyPaid: true };
    }

    // Defaults to a full payment (remaining balance) — every existing
    // caller that doesn't pass `amount` keeps working exactly as before.
    const paymentAmount = amount ?? remainingBalance;
    if (paymentAmount <= 0) {
        return { error: "Payment amount must be greater than zero." };
    }
    if (paymentAmount > remainingBalance) {
        return { error: `Payment amount exceeds the remaining balance of ${remainingBalance}.` };
    }

    const willFullyPay = paymentAmount === remainingBalance;

    // A delivery order can only be FULLY completed once the rider has
    // marked it delivered — a partial payment taken earlier (e.g. a
    // deposit at order time) doesn't need to wait for that.
    let deliveryNeedsAutoConfirm = false;
    if (willFullyPay && target.orderType === "delivery") {
        const delivery = await db.query.deliveries.findFirst({ where: eq(deliveries.orderId, orderId) });
        if (!delivery) {
            return { error: "Delivery record not found." };
        }
        if (delivery.status !== "delivered") {
            if (!clientPaymentId) {
                return { error: "This delivery hasn't been marked delivered by the rider yet." };
            }
            // Offline completion: riders don't use the app mid-delivery
            // while offline (per design — staff assigns them, they
            // deliver and bring cash back physically). Staff completing
            // the bill IS the delivery confirmation here, so mark it
            // delivered as part of this same action instead of requiring
            // a rider-side step that can't happen without a connection.
            deliveryNeedsAutoConfirm = true;
        }
    }

    let paymentId = "";
    let lowStockAlerts: LowStockAlert[] = [];

    await db.transaction(async (tx) => {
        const now = new Date();
        const newTotalPaid = target.totalPaid + paymentAmount;

        if (deliveryNeedsAutoConfirm) {
            await tx
                .update(deliveries)
                .set({ status: "delivered", updatedAt: now, actualDeliveryTime: now })
                .where(eq(deliveries.orderId, orderId));
        }

        await tx
            .update(orders)
            .set({
                // Only flips to "completed" once the full total is paid —
                // a partial payment leaves status untouched so the order
                // stays open for the next payment.
                ...(willFullyPay ? { status: "completed" as const, completedAt: now } : {}),
                paymentStatus: willFullyPay ? "paid" : "partial",
                totalPaid: newTotalPaid,
                balance: target.total - newTotalPaid,
                updatedAt: now,
            })
            .where(eq(orders.id, orderId));

        const payment = await PaymentService.initiate(
            {
                tenantId: currentStaffRow.tenantId,
                branchId: target.branchId,
                orderId,
                amount: paymentAmount,
                currency: "PKR",
                method: paymentMethod,
                clientPaymentId,
                processedBy: currentStaffRow.id,
                processedByName: `${currentStaffRow.firstName} ${currentStaffRow.lastName}`,
            },
            "manual",
            tx
        );

        paymentId = payment.paymentId;

        // Table frees up on ANY payment against the order, not just a
        // full one — Zakir's explicit call, since taking a payment (even
        // partial) generally means the table is being vacated.
        if (target.tableId) {
            await tx
                .update(restaurantTables)
                .set({ status: "available", updatedAt: now })
                .where(eq(restaurantTables.id, target.tableId));
        }

        if (willFullyPay) {
            lowStockAlerts = await deductInventoryForCompletedOrder(tx, {
                tenantId: currentStaffRow.tenantId,
                branchId: target.branchId,
                orderId,
                staffId: currentStaffRow.id,
                staffName: `${currentStaffRow.firstName} ${currentStaffRow.lastName}`,
            });
        }
    });

    if (deliveryNeedsAutoConfirm) {
        await Promise.all([
            logAudit(db, currentStaffRow, "delivery", orderId, "status_change", {
                branchId: target.branchId,
                oldValue: { status: "assigned/out_for_delivery" },
                newValue: { status: "delivered", note: "Auto-confirmed at offline completion — rider had no connection to confirm it themselves." },
            }),
            broadcastChange(target.branchId, "riders"),
        ]);
    }

    await logAudit(db, currentStaffRow, "order", orderId, "status_change", {
        branchId: target.branchId,
        oldValue: { status: target.status, paymentStatus: target.paymentStatus },
        newValue: {
            status: willFullyPay ? "completed" : target.status,
            paymentStatus: willFullyPay ? "paid" : "partial",
            paymentMethod,
            amount: paymentAmount,
            orderNumber: target.orderNumber,
        },
    });

    await logAudit(db, currentStaffRow, "payment", paymentId, "create", {
        branchId: target.branchId,
        newValue: { orderId, method: paymentMethod, amount: paymentAmount, orderNumber: target.orderNumber },
    });

    await broadcastChange(target.branchId, "orders");
    if (target.tableId) {
        await broadcastChange(target.branchId, "tables");
    }
    for (const alert of lowStockAlerts) {
        await createNotification({
            tenantId: currentStaffRow.tenantId,
            branchId: alert.branchId,
            type: "low_stock",
            title: "Low stock",
            message: `${alert.ingredientName} is low: ${alert.currentStock} ${alert.unit} left.`,
            resourceType: "ingredient",
            resourceId: alert.ingredientId,
        });
    }

    return { success: true, fullyPaid: willFullyPay };
}

// ─── Record Split Payment ────────────────────────────────────────────────

export interface SplitPaymentLine {
    method: PaymentMethod;
    amount: number;
}

// Records multiple payments (different methods) against one order in a
// single transaction — e.g. a dine-in customer paying Rs. 1000 cash + Rs.
// 1500 EasyPaisa for one bill. Only completes the order once the lines add
// up to the exact remaining balance; otherwise it stays open with a
// smaller balance (same "partial" behavior as completeBillAction's amount
// param, just across several methods at once instead of one).
export async function recordSplitPaymentAction(
    orderId: string,
    lines: SplitPaymentLine[]
): Promise<{ success: true; fullyPaid: boolean } | { success?: undefined; error: string }> {
    const auth = await getCurrentStaff();
    if (!auth.ok) return { error: auth.error };
    const { staff: currentStaffRow } = auth;

    const target = await db.query.orders.findFirst({ where: eq(orders.id, orderId) });
    if (!target || target.tenantId !== currentStaffRow.tenantId) {
        return { error: "Order not found." };
    }
    if (currentStaffRow.role !== "SUPER_ADMIN" && target.branchId !== currentStaffRow.branchId) {
        return { error: "You can only manage your own branch's orders." };
    }
    if (target.status === "completed" || target.status === "cancelled") {
        return { error: `Cannot record a payment on an order that is already "${target.status}".` };
    }

    if (lines.length === 0) {
        return { error: "Add at least one payment line." };
    }
    for (const line of lines) {
        if (!line.amount || line.amount <= 0) {
            return { error: "Every payment line must have an amount greater than zero." };
        }
    }

    const remainingBalance = target.total - target.totalPaid;
    const linesTotal = lines.reduce((sum, l) => sum + l.amount, 0);

    if (linesTotal > remainingBalance) {
        return { error: `These payments add up to more than the remaining balance of ${remainingBalance}.` };
    }

    // Split Payment only ever RECORDS payment lines â€” it never completes
    // the order itself, even if the lines happen to sum to the full
    // balance. Completing (and printing the final bill) is always a
    // separate, explicit step via Complete Order / Print Bill â€” same as
    // how an already-fully-paid PayFast order still needs completing.
    const fullyPaid = linesTotal === remainingBalance;

    const paymentIds: string[] = [];

    await db.transaction(async (tx) => {
        const now = new Date();
        const newTotalPaid = target.totalPaid + linesTotal;

        await tx
            .update(orders)
            .set({
                paymentStatus: fullyPaid ? "paid" : "partial",
                totalPaid: newTotalPaid,
                balance: target.total - newTotalPaid,
                updatedAt: now,
            })
            .where(eq(orders.id, orderId));

        for (const line of lines) {
            const payment = await PaymentService.initiate(
                {
                    tenantId: currentStaffRow.tenantId,
                    branchId: target.branchId,
                    orderId,
                    amount: line.amount,
                    currency: "PKR",
                    method: line.method,
                    processedBy: currentStaffRow.id,
                    processedByName: `${currentStaffRow.firstName} ${currentStaffRow.lastName}`,
                },
                "manual",
                tx
            );
            paymentIds.push(payment.paymentId);
        }

        // Table frees on any payment, partial or full â€” same as
        // completeBillAction's existing behavior.
        if (target.tableId) {
            await tx
                .update(restaurantTables)
                .set({ status: "available", updatedAt: now })
                .where(eq(restaurantTables.id, target.tableId));
        }
    });

    await logAudit(db, currentStaffRow, "order", orderId, "status_change", {
        branchId: target.branchId,
        oldValue: { status: target.status, paymentStatus: target.paymentStatus },
        newValue: {
            status: target.status,
            paymentStatus: fullyPaid ? "paid" : "partial",
            splitPayment: true,
            lines,
            orderNumber: target.orderNumber,
        },
    });

    for (const paymentId of paymentIds) {
        await logAudit(db, currentStaffRow, "payment", paymentId, "create", {
            branchId: target.branchId,
            newValue: { orderId, orderNumber: target.orderNumber },
        });
    }

    await broadcastChange(target.branchId, "orders");
    if (target.tableId) {
        await broadcastChange(target.branchId, "tables");
    }

    return { success: true, fullyPaid };
}

// ─── Cancel Order ────────────────────────────────────────────────────────

export async function cancelOrderAction(
    orderId: string
): Promise<{ success: true } | { success?: undefined; error: string }> {
    const auth = await getCurrentStaff();
    if (!auth.ok) return { error: auth.error };
    const { staff: currentStaffRow } = auth;

    const target = await db.query.orders.findFirst({ where: eq(orders.id, orderId) });
    if (!target || target.tenantId !== currentStaffRow.tenantId) {
        return { error: "Order not found." };
    }
    if (currentStaffRow.role !== "SUPER_ADMIN" && target.branchId !== currentStaffRow.branchId) {
        return { error: "You can only manage your own branch's orders." };
    }
    if (target.status === "completed" || target.status === "cancelled") {
        return { error: `Cannot cancel an order that is already "${target.status}".` };
    }

    await db.transaction(async (tx) => {
        await tx.update(orders).set({ status: "cancelled", updatedAt: new Date() }).where(eq(orders.id, orderId));

        if (target.tableId) {
            await tx
                .update(restaurantTables)
                .set({ status: "available", updatedAt: new Date() })
                .where(eq(restaurantTables.id, target.tableId));
        }
    });

    await logAudit(db, currentStaffRow, "order", orderId, "status_change", {
        branchId: target.branchId,
        oldValue: { status: target.status },
        newValue: { status: "cancelled", orderNumber: target.orderNumber },
    });

    await broadcastChange(target.branchId, "orders");
    if (target.tableId) {
        await broadcastChange(target.branchId, "tables");
    }

    return { success: true };
}


// ─── Refund Payment ─────────────────────────────────────────────────────

export async function refundPaymentAction(
    paymentId: string,
    amount: number,
    reason?: string
): Promise<{ success: true } | { success?: undefined; error: string }> {
    const auth = await getCurrentStaff();
    if (!auth.ok) return { error: auth.error };
    const { staff: currentStaffRow } = auth;

    if (!hasPermission(currentStaffRow.role, "manage_orders")) {
        return { error: "You don't have permission to refund payments." };
    }

    const payment = await db.query.payments.findFirst({ where: eq(payments.id, paymentId) });
    if (!payment || payment.tenantId !== currentStaffRow.tenantId) {
        return { error: "Payment not found." };
    }
    if (currentStaffRow.role !== "SUPER_ADMIN" && payment.branchId !== currentStaffRow.branchId) {
        return { error: "You can only manage your own branch's payments." };
    }
    if (payment.status !== "paid") {
        return { error: `Cannot refund a payment that is "${payment.status}".` };
    }
    if (amount <= 0 || amount > payment.amount) {
        return { error: "Refund amount must be between 0 and the original payment amount." };
    }

    const result = await PaymentService.refund(
        {
            paymentId: payment.id,
            tenantId: payment.tenantId,
            amount,
            reason,
            createdBy: currentStaffRow.id,
            createdByName: `${currentStaffRow.firstName} ${currentStaffRow.lastName}`,
        },
        payment.provider ?? "manual"
    );

    // The refund above only updated the payment row itself — the order's
    // own totals must be corrected too, or it keeps showing "Paid" for
    // money that was actually returned to the customer.
    const order = await db.query.orders.findFirst({ where: eq(orders.id, payment.orderId) });
    if (order) {
        const newTotalPaid = Math.max(0, order.totalPaid - amount);
        const newBalance = order.total - newTotalPaid;
        const newPaymentStatus =
            newTotalPaid <= 0 ? "refunded" : newBalance > 0 ? "partial" : "paid";

        await db
            .update(orders)
            .set({
                totalPaid: newTotalPaid,
                balance: newBalance,
                paymentStatus: newPaymentStatus,
                updatedAt: new Date(),
            })
            .where(eq(orders.id, order.id));
    }

    await logAudit(db, currentStaffRow, "payment", payment.id, "refund", {
        branchId: payment.branchId,
        newValue: { amount, reason, refundId: result.refundId },
    });

    if (payment.branchId) {
        await broadcastChange(payment.branchId, "orders");
    }

    return { success: true };
}