"use server";

import { db } from "@/db";
import {
    orders,
    orderItems,
    orderCounters,
    menuItems,
    menuCategories,
    branches,
    branchDeliveryAreas,
    tenantSettings,
    deliveries,
} from "@/db/schema";
import { eq, and, inArray, sql, asc } from "drizzle-orm";
import type { Order, MenuCategory, MenuItem } from "@/types";
import { RESTAURANT_CONFIG } from "@/config/restaurant";
import { getTenantId } from "@/lib/tenant";
import { logAudit } from "@/lib/audit";
import { publicOrderRateLimit } from "@/lib/rate-limit";
import { headers } from "next/headers";
import { broadcastChange } from "@/lib/realtime/broadcast";
import { createNotification } from "../notifications/actions";

const ONLINE_ORDER_ACTOR = (tenantId: string, branchId: string) => ({
  id: null, // no real staff row — actorId column is uuid, must be null not a placeholder string
  tenantId,
  branchId,
  firstName: "Online",
  lastName: "Order",
});


// ─── Website menu (marketing homepage) ──────────────────────────────────
// The homepage isn't location-aware like the real /order flow, so it just
// shows one branch's menu: the earliest-created active branch, for now.
// (A per-tenant override setting is coming next — this fallback will stay
// in place for tenants who never set one.)
export async function getPublicWebsiteMenuAction(): Promise <
    | { data: { categories: MenuCategory[]; items: MenuItem[] }; error?: undefined }
    | { data: null; error: string }
> {
    const tenantId = getTenantId();

    // Prefer the SUPER_ADMIN-configured website branch, if one is set and
    // still points to an active branch belonging to this tenant. Otherwise
    // fall back to the earliest-created active branch.
    const settings = await db.query.tenantSettings.findFirst({
        where: eq(tenantSettings.tenantId, tenantId),
        columns: { websiteBranchId: true },
    });

    let targetBranchId = settings?.websiteBranchId ?? null;

    if (targetBranchId) {
        const configuredBranch = await db.query.branches.findFirst({
            where: and(
                eq(branches.id, targetBranchId),
                eq(branches.tenantId, tenantId),
                eq(branches.isActive, true)
            ),
        });
        if (!configuredBranch) targetBranchId = null;
    }

    if (!targetBranchId) {
        const flagshipBranch = await db.query.branches.findFirst({
            where: and(eq(branches.tenantId, tenantId), eq(branches.isActive, true)),
            orderBy: [asc(branches.createdAt)],
        });
        if (!flagshipBranch) {
            return { data: null, error: "No active branches configured for this restaurant." };
        }
        targetBranchId = flagshipBranch.id;
    }

    return getPublicMenuAction(targetBranchId);
}


// ─── Branch info (drives whether the location modal shows at all) ──────

export async function getPublicBranchInfoAction(): Promise <
    | { data: { branchCount: number; singleBranch?: { id: string; name: string } }; error?: undefined }
    | { data: null; error: string }
> {
    const tenantId = getTenantId();

    const branchRows = await db.query.branches.findMany({
        where: and(eq(branches.tenantId, tenantId), eq(branches.isActive, true)),
    });

    if (branchRows.length === 0) {
        return { data: null, error: "No active branches configured for this restaurant." };
    }

    if (branchRows.length === 1) {
        return {
            data: {
                branchCount: 1,
                singleBranch: { id: branchRows[0].id, name: branchRows[0].name },
            },
        };
    }

    return { data: { branchCount: branchRows.length } };
}

// ─── Delivery areas, grouped for a cascading city → area picker ────────

export async function getPublicDeliveryAreasAction(): Promise <
    | { data: { city: string; areas: { area: string; branchId: string }[] }[]; error?: undefined }
    | { data: null; error: string }
> {
    const tenantId = getTenantId();

    const activeBranches = await db.query.branches.findMany({
        where: and(eq(branches.tenantId, tenantId), eq(branches.isActive, true)),
        columns: { id: true },
    });
    const activeBranchIds = activeBranches.map((b) => b.id);
    if (activeBranchIds.length === 0) {
        return { data: null, error: "No active branches configured for this restaurant." };
    }

    const rows = await db.query.branchDeliveryAreas.findMany({
        where: and(
            eq(branchDeliveryAreas.tenantId, tenantId),
            inArray(branchDeliveryAreas.branchId, activeBranchIds)
        ),
        orderBy: [asc(branchDeliveryAreas.city), asc(branchDeliveryAreas.area)],
    });

    const grouped = new Map<string, { area: string; branchId: string }[]>();
    for (const row of rows) {
        const list = grouped.get(row.city) ?? [];
        list.push({ area: row.area, branchId: row.branchId });
        grouped.set(row.city, list);
    }

    const data = Array.from(grouped.entries()).map(([city, areas]) => ({ city, areas }));
    return { data };
}

// ─── Public menu for a resolved branch ──────────────────────────────────

export async function getPublicMenuAction(
    branchId: string
): Promise <
    | { data: { categories: MenuCategory[]; items: MenuItem[] }; error?: undefined }
    | { data: null; error: string }
> {
    const tenantId = getTenantId();

    const branch = await db.query.branches.findFirst({
        where: and(eq(branches.id, branchId), eq(branches.tenantId, tenantId), eq(branches.isActive, true)),
    });
    if (!branch) return { data: null, error: "This branch is not available." };

    const categoryRows = await db.query.menuCategories.findMany({
        where: and(
            eq(menuCategories.tenantId, tenantId),
            eq(menuCategories.branchId, branchId),
            eq(menuCategories.isActive, true)
        ),
        orderBy: [asc(menuCategories.sortOrder)],
    });

    const itemRows = await db.query.menuItems.findMany({
        where: and(
            eq(menuItems.tenantId, tenantId),
            eq(menuItems.branchId, branchId),
            eq(menuItems.status, "available")
        ),
        orderBy: [asc(menuItems.sortOrder)],
        with: { variants: true, modifierGroups: { with: { options: true } } },
    });

    const categories: MenuCategory[] = categoryRows.map((c) => ({
        id: c.id,
        branchId: c.branchId,
        name: c.name,
        slug: c.slug,
        description: c.description ?? undefined,
        image: c.image ?? undefined,
        icon: c.icon ?? undefined,
        sortOrder: c.sortOrder,
        isActive: c.isActive,
        createdAt: c.createdAt.toISOString(),
        updatedAt: c.updatedAt.toISOString(),
    }));

    const items: MenuItem[] = itemRows.map((i) => ({
        id: i.id,
        branchId: i.branchId,
        categoryId: i.categoryId,
        name: i.name,
        slug: i.slug,
        description: i.description,
        image: i.image ?? undefined,
        basePrice: i.basePrice,
        variants: i.variants.map((v) => ({
            id: v.id, name: v.name, price: v.price, isDefault: v.isDefault, isAvailable: v.isAvailable,
        })),
        modifierGroups: i.modifierGroups.map((g) => ({
            id: g.id, name: g.name, isRequired: g.isRequired,
            minSelections: g.minSelections, maxSelections: g.maxSelections,
            options: g.options.map((o) => ({
                id: o.id, name: o.name, priceAdjustment: o.priceAdjustment,
                isDefault: o.isDefault, isAvailable: o.isAvailable,
            })),
        })),
        status: i.status,
        sortOrder: i.sortOrder,
        isFeatured: i.isFeatured,
        createdAt: i.createdAt.toISOString(),
        updatedAt: i.updatedAt.toISOString(),
    }));

    return { data: { categories, items } };
}

// ─── Create public (customer-facing) order ──────────────────────────────

export interface PublicOrderItemInput {
    menuItemId: string;
    variantId?: string;
    modifierOptionIds: string[];
    quantity: number;
    notes?: string;
}

export interface CreatePublicOrderInput {
    branchId: string; // resolved via location picker or branch switcher
    customerName?: string;
    customerPhone: string;
    deliveryAddress: string;
    city: string;
    area?: string; // absent when the branch was picked directly via the switcher
    items: PublicOrderItemInput[];
    notes?: string;
}

export async function createPublicOrderAction(
    input: CreatePublicOrderInput
): Promise<{ success: true; order: Order } | { success?: undefined; error: string }> {
    const tenantId = getTenantId();

    if (input.items.length === 0) return { error: "Cannot place an order with no items." };
    if (!input.customerPhone?.trim()) return { error: "A phone number is required." };
    if (!input.deliveryAddress?.trim()) return { error: "A delivery address is required." };

    const headersList = await headers();
    const ip = headersList.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
    const { success } = await publicOrderRateLimit.limit(ip);
    if (!success) {
        return { error: "Too many orders placed. Please wait a few minutes and try again." };
    }

    try {
        const result = await db.transaction(async (tx) => {
            const branch = await tx.query.branches.findFirst({
                where: and(eq(branches.id, input.branchId), eq(branches.tenantId, tenantId), eq(branches.isActive, true)),
            });
            if (!branch) throw new Error("Selected branch is not available.");

            const menuItemIds = [...new Set(input.items.map((i) => i.menuItemId))];
            const realMenuItems = await tx.query.menuItems.findMany({
                where: and(
                    inArray(menuItems.id, menuItemIds),
                    eq(menuItems.tenantId, tenantId),
                    eq(menuItems.branchId, input.branchId)
                ),
                with: { variants: true, modifierGroups: { with: { options: true } } },
            });
            const menuItemMap = new Map(realMenuItems.map((m) => [m.id, m]));

            const builtItems = input.items.map((line) => {
                const menuItem = menuItemMap.get(line.menuItemId);
                if (!menuItem) throw new Error(`Menu item not found: ${line.menuItemId}`);
                if (menuItem.status !== "available") throw new Error(`"${menuItem.name}" is currently unavailable.`);

                let unitPrice = menuItem.basePrice;
                let selectedVariant = null;
                if (line.variantId) {
                    const variant = menuItem.variants.find((v) => v.id === line.variantId);
                    if (!variant) throw new Error(`Invalid variant for "${menuItem.name}".`);
                    unitPrice = variant.price;
                    selectedVariant = { variantId: variant.id, variantName: variant.name, priceAdjustment: 0 };
                }

                const allOptions = menuItem.modifierGroups.flatMap((g) =>
                    g.options.map((o) => ({ ...o, groupId: g.id, groupName: g.name }))
                );
                const selectedModifiers = line.modifierOptionIds.map((optId) => {
                    const opt = allOptions.find((o) => o.id === optId);
                    if (!opt) throw new Error(`Invalid option for "${menuItem.name}".`);
                    unitPrice += opt.priceAdjustment;
                    return {
                        groupId: opt.groupId, groupName: opt.groupName,
                        optionId: opt.id, optionName: opt.name, priceAdjustment: opt.priceAdjustment,
                    };
                });

                return {
                    menuItemId: menuItem.id,
                    menuItemName: menuItem.name,
                    menuItemImage: menuItem.image ?? null,
                    categoryId: menuItem.categoryId,
                    categoryName: "",
                    quantity: line.quantity,
                    unitPrice,
                    itemTotal: unitPrice * line.quantity,
                    selectedVariant,
                    selectedModifiers,
                    notes: line.notes ?? null,
                };
            });

            const categoryIds = [...new Set(builtItems.map((i) => i.categoryId))];
            const categoryRows = await tx.query.menuCategories.findMany({
                where: inArray(menuCategories.id, categoryIds),
            });
            const categoryNameMap = new Map(categoryRows.map((c) => [c.id, c.name]));
            for (const item of builtItems) {
                item.categoryName = categoryNameMap.get(item.categoryId) ?? "Uncategorized";
            }

            const subtotal = builtItems.reduce((sum, i) => sum + i.itemTotal, 0);
            const deliveryFee =
                RESTAURANT_CONFIG.enableFreeDelivery && subtotal >= RESTAURANT_CONFIG.freeDeliveryThreshold
                    ? 0
                    : RESTAURANT_CONFIG.defaultDeliveryFee;
            const total = subtotal + deliveryFee;

            const [counter] = await tx
                .insert(orderCounters)
                .values({ branchId: input.branchId, tenantId, nextNumber: 2 })
                .onConflictDoUpdate({
                    target: orderCounters.branchId,
                    set: { nextNumber: sql`${orderCounters.nextNumber} + 1` },
                })
                .returning();
            const orderNumber = `ORD-${String(counter.nextNumber - 1).padStart(4, "0")}`;

            const [createdOrder] = await tx
                .insert(orders)
                .values({
                    tenantId,
                    branchId: input.branchId,
                    orderNumber,
                    customerPhone: input.customerPhone,
                    customerName: input.customerName ?? null,
                    orderType: "delivery",
                    status: "pending",
                    subtotal,
                    totalDiscount: 0,
                    deliveryFee,
                    total,
                    deliveryAddress: [input.deliveryAddress, input.area, input.city]
                        .filter((part) => part && part.trim().length > 0)
                        .join(", "),
                    notes: input.notes ?? null,
                    staffId: null,
                })
                .returning();

                await tx.insert(deliveries).values({
                tenantId,
                branchId: input.branchId,
                orderId: createdOrder.id,
                riderId: null,
                status: "unassigned",
                deliveryAddress: {
                    label: null,
                    street: input.deliveryAddress,
                    area: input.area ?? "",
                    city: input.city,
                    instructions: input.notes ?? null,
                },
                deliveryFee,
            });

            const insertedItems = await tx
                .insert(orderItems)
                .values(
                    builtItems.map((i) => ({
                        tenantId,
                        orderId: createdOrder.id,
                        menuItemId: i.menuItemId,
                        menuItemName: i.menuItemName,
                        menuItemImage: i.menuItemImage,
                        categoryId: i.categoryId,
                        categoryName: i.categoryName,
                        quantity: i.quantity,
                        unitPrice: i.unitPrice,
                        itemTotal: i.itemTotal,
                        selectedVariant: i.selectedVariant,
                        selectedModifiers: i.selectedModifiers,
                        notes: i.notes,
                    }))
                )
                .returning();

            return { order: createdOrder, items: insertedItems };
        });

        await logAudit(
            db,
            ONLINE_ORDER_ACTOR(tenantId, input.branchId),
            "order",
            result.order.id,
            "create",
            {
                branchId: input.branchId,
                newValue: {
                    orderNumber: result.order.orderNumber,
                    orderType: result.order.orderType,
                    customerPhone: input.customerPhone,
                    itemCount: result.items.length,
                    source: "online-ordering",
                },
            }
        );

        await Promise.all([
            broadcastChange(result.order.branchId, "orders"),
            createNotification({
                tenantId,
                branchId: result.order.branchId,
                type: "order_new",
                title: "New order",
                message: `Order ${result.order.orderNumber} placed (online, ${result.order.orderType}).`,
                resourceType: "order",
                resourceId: result.order.id,
            }),
        ]);

        return {
            success: true,
            order: {
                id: result.order.id,
                orderNumber: result.order.orderNumber,
                branchId: result.order.branchId,
                customerPhone: result.order.customerPhone ?? undefined,
                orderType: result.order.orderType,
                status: result.order.status,
                wasOfflineOrder: false,
                items: result.items.map((i) => ({
                    id: i.id,
                    orderId: i.orderId,
                    menuItemId: i.menuItemId,
                    menuItemName: i.menuItemName,
                    menuItemImage: i.menuItemImage ?? undefined,
                    categoryId: i.categoryId,
                    categoryName: i.categoryName,
                    quantity: i.quantity,
                    unitPrice: i.unitPrice,
                    selectedVariant: i.selectedVariant ?? undefined,
                    selectedModifiers: i.selectedModifiers,
                    itemTotal: i.itemTotal,
                    notes: i.notes ?? undefined,
                    status: i.status,
                    createdAt: i.createdAt.toISOString(),
                })),
                subtotal: result.order.subtotal,
                discounts: [],
                totalDiscount: result.order.totalDiscount,
                deliveryFee: result.order.deliveryFee,
                total: result.order.total,
                paymentStatus: result.order.paymentStatus,
                payments: [],
                totalPaid: result.order.totalPaid,
                balance: result.order.total,
                deliveryAddress: result.order.deliveryAddress ?? undefined,
                notes: result.order.notes ?? undefined,
                staffId: result.order.staffId,
                createdAt: result.order.createdAt.toISOString(),
                updatedAt: result.order.updatedAt.toISOString(),
            },
        };
    } catch (err) {
        return { error: (err as Error).message };
    }
}

// ─── Distinct cities with active branches (drives the new city-picker step) ─

export async function getPublicCitiesAction(): Promise <
    | { data: string[]; error?: undefined }
    | { data: null; error: string }
> {
    const tenantId = getTenantId();

    const rows = await db
        .selectDistinct({ city: branches.city })
        .from(branches)
        .where(and(eq(branches.tenantId, tenantId), eq(branches.isActive, true)))
        .orderBy(asc(branches.city));

    if (rows.length === 0) {
        return { data: null, error: "No active branches configured for this restaurant." };
    }

    return { data: rows.map((r) => r.city) };
}

// ─── Delivery areas within one city (used by /order after city is picked) ──

export async function getPublicAreasForCityAction(
    city: string
): Promise <
    | { data: { area: string; branchId: string }[]; error?: undefined }
    | { data: null; error: string }
> {
    const tenantId = getTenantId();

    const activeBranches = await db.query.branches.findMany({
        where: and(
            eq(branches.tenantId, tenantId),
            eq(branches.isActive, true),
            eq(branches.city, city)
        ),
        columns: { id: true },
    });
    const activeBranchIds = activeBranches.map((b) => b.id);
    if (activeBranchIds.length === 0) {
        return { data: null, error: "No branches found in this city." };
    }

    const rows = await db.query.branchDeliveryAreas.findMany({
        where: and(
            eq(branchDeliveryAreas.tenantId, tenantId),
            eq(branchDeliveryAreas.city, city),
            inArray(branchDeliveryAreas.branchId, activeBranchIds)
        ),
        orderBy: [asc(branchDeliveryAreas.area)],
    });

    return { data: rows.map((r) => ({ area: r.area, branchId: r.branchId })) };
}

// ─── Branches within one city (used by /book-a-table and the branch switcher) ─

export async function getPublicBranchesByCityAction(
    city: string
): Promise <
    | { data: { id: string; name: string; address: string | null }[]; error?: undefined }
    | { data: null; error: string }
> {
    const tenantId = getTenantId();

    const rows = await db.query.branches.findMany({
        where: and(
            eq(branches.tenantId, tenantId),
            eq(branches.isActive, true),
            eq(branches.city, city)
        ),
        orderBy: [asc(branches.name)],
    });

    if (rows.length === 0) {
        return { data: null, error: "No branches found in this city." };
    }

    return { data: rows.map((b) => ({ id: b.id, name: b.name, address: b.address })) };
}