"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useForm, useFieldArray, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { X, Loader2, Plus, Trash2, Upload, ImageIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import type { MenuCategory, MenuItem } from "@/types";
import type { Control, FieldErrors, UseFormRegister } from "react-hook-form";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";

// ─── Schema ───────────────────────────────────────────────────────────────────

const variantSchema = z.object({
    id: z.string().optional(),
    name: z.string().min(1, "Required"),
    price: z.number().min(0, "Required"),
    isDefault: z.boolean(),
    isAvailable: z.boolean(),
});

const modifierOptionSchema = z.object({
    id: z.string().optional(),
    name: z.string().min(1, "Required"),
    priceAdjustment: z.number(),
    isDefault: z.boolean(),
    isAvailable: z.boolean(),
});

const modifierGroupSchema = z.object({
    id: z.string().optional(),
    name: z.string().min(1, "Required"),
    isRequired: z.boolean(),
    minSelections: z.number().min(0),
    maxSelections: z.number().min(1),
    options: z.array(modifierOptionSchema).min(1, "Add at least one option"),
});

const itemSchema = z.object({
    categoryId: z.string().min(1, "Category is required"),
    name: z.string().min(1, "Name is required").max(100),
    basePrice: z.number().min(0, "Price is required"),
    status: z.enum(["available", "unavailable", "out_of_stock"]),
    variants: z.array(variantSchema),
    modifierGroups: z.array(modifierGroupSchema),
});

type ItemFormValues = z.infer<typeof itemSchema>;

// ─── Props ────────────────────────────────────────────────────────────────────
interface ItemFormModalProps {
    isOpen: boolean;
    item: MenuItem | null;
    categories: MenuCategory[];
    isLoading: boolean;
    onSubmit: (values: ItemFormValues, imageFile: File | null) => void;
    onClose: () => void;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

const labelClass = "text-xs font-medium text-muted-foreground mb-1.5 block";

const STATUS_OPTIONS = ["available", "out_of_stock", "unavailable"] as const;

const MAX_FILE_SIZE = 5 * 1024 * 1024;
const ALLOWED_TYPES = ["image/jpeg", "image/png", "image/webp"];

const DEFAULT_VALUES: ItemFormValues = {
    categoryId: "",
    name: "",
    basePrice: 0,
    status: "available",
    variants: [],
    modifierGroups: [],
};

// ─── Sub-components ───────────────────────────────────────────────────────────

function SectionTitle({ children }: { children: React.ReactNode }) {
    return (
        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide pt-2">
            {children}
        </h3>
    );
}

// ─── Component ────────────────────────────────────────────────────────────────

export function ItemFormModal({
    isOpen,
    item,
    categories,
    isLoading,
    onSubmit,
    onClose,
}: ItemFormModalProps) {
    const isEdit = !!item;

    const {
        register,
        handleSubmit,
        reset,
        control,
        formState: { errors },
    } = useForm<ItemFormValues>({
        resolver: zodResolver(itemSchema),
        defaultValues: DEFAULT_VALUES,
    });

    const {
        fields: variantFields,
        append: appendVariant,
        remove: removeVariant,
    } = useFieldArray({ control, name: "variants" });

    const {
        fields: modifierFields,
        append: appendModifier,
        remove: removeModifier,
    } = useFieldArray({ control, name: "modifierGroups" });

    const fileInputRef = useRef<HTMLInputElement>(null);
    const [selectedFile, setSelectedFile] = useState<File | null>(null);
    const [imageError, setImageError] = useState<string | null>(null);

    // Derived, not stored — avoids needing an effect to keep it in sync.
    const previewUrl = useMemo(() => {
        if (selectedFile) return URL.createObjectURL(selectedFile);
        return item?.image ?? null;
    }, [selectedFile, item]);

    // Object URLs must be revoked to avoid leaking memory — this is a real
    // "subscribe to an external system" case, so an effect is correct here.
    useEffect(() => {
        return () => {
            if (selectedFile && previewUrl) URL.revokeObjectURL(previewUrl);
        };
    }, [selectedFile, previewUrl]);

    function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
        const file = e.target.files?.[0];
        if (!file) return;

        if (!ALLOWED_TYPES.includes(file.type)) {
            setImageError("Only JPEG, PNG, or WebP images are allowed.");
            return;
        }
        if (file.size > MAX_FILE_SIZE) {
            setImageError("Image must be under 5MB.");
            return;
        }

        setImageError(null);
        setSelectedFile(file);
    }

    function clearSelectedImage() {
        setSelectedFile(null);
        if (fileInputRef.current) fileInputRef.current.value = "";
    }

    function handleFormSubmit(values: ItemFormValues) {
        onSubmit(values, selectedFile);
    }

    useEffect(() => {
        if (!isOpen) return;
        if (item) {
            reset({
                categoryId: item.categoryId,
                name: item.name,
                basePrice: item.basePrice,
                status: item.status,
                variants: item.variants,
                modifierGroups: item.modifierGroups,
            });
        } else {
            reset(DEFAULT_VALUES);
        }
    }, [isOpen, item, reset]);

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
            <div className="absolute inset-0 bg-black/50" onClick={onClose} />

            <div className="relative z-10 w-full max-w-2xl bg-card rounded-2xl shadow-xl border border-border mx-4 flex flex-col max-h-[90vh] overflow-hidden">

                {/* Header */}
                <div className="shrink-0 flex items-center justify-between px-6 py-4 border-b">
                    <h2 className="text-base font-semibold">{isEdit ? "Edit Item" : "Add Item"}</h2>
                    <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors">
                        <X className="w-4 h-4" />
                    </button>
                </div>

                {/* Body */}
                <div className="flex-1 overflow-y-auto min-h-0 px-6 py-5">
                    <form id="item-form" onSubmit={handleSubmit(handleFormSubmit)} className="space-y-5">

                        <SectionTitle>Basic Info</SectionTitle>

                        {/* Photo */}
                        <div>
                            <label className={labelClass}>Photo (optional)</label>
                            <div className="flex items-center gap-3">
                                <div className="h-16 w-16 rounded-lg overflow-hidden bg-muted border flex items-center justify-center shrink-0">
                                    {previewUrl ? (
                                        // eslint-disable-next-line @next/next/no-img-element
                                        <img src={previewUrl} alt="Preview" className="h-full w-full object-cover" />
                                    ) : (
                                        <ImageIcon className="w-6 h-6 text-muted-foreground" />
                                    )}
                                </div>
                                <div className="flex gap-2">
                                    <button
                                        type="button"
                                        onClick={() => fileInputRef.current?.click()}
                                        className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border rounded-lg hover:bg-muted transition-colors"
                                    >
                                        <Upload className="w-3.5 h-3.5" />
                                        {previewUrl ? "Change" : "Upload"}
                                    </button>
                                    {selectedFile && (
                                        <button
                                            type="button"
                                            onClick={clearSelectedImage}
                                            className="p-1.5 rounded-lg hover:bg-red-50 text-muted-foreground hover:text-red-600 transition-colors"
                                        >
                                            <X className="w-3.5 h-3.5" />
                                        </button>
                                    )}
                                </div>
                                <input
                                    ref={fileInputRef}
                                    type="file"
                                    accept="image/jpeg,image/png,image/webp"
                                    className="hidden"
                                    onChange={handleFileChange}
                                />
                            </div>
                            {imageError && <p className="text-xs text-destructive mt-1.5">{imageError}</p>}
                        </div>

                        {/* Category */}
                        <div>
                            <label className={labelClass}>Category <span className="text-destructive">*</span></label>
                            <Controller
                                control={control}
                                name="categoryId"
                                render={({ field }) => (
                                    <Select value={field.value} onValueChange={(v) => v && field.onChange(v)}>
                                        <SelectTrigger className={cn("w-full", errors.categoryId && "border-destructive")}>
                                            <SelectValue placeholder="Select category...">
                                                {(value: string) => {
                                                    const cat = categories.find((c) => c.id === value);
                                                    return cat ? `${cat.icon} ${cat.name}` : "Select category...";
                                                }}
                                            </SelectValue>
                                        </SelectTrigger>
                                        <SelectContent>
                                            {categories.filter((c) => c.isActive).map((c) => (
                                                <SelectItem key={c.id} value={c.id}>{c.icon} {c.name}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                )}
                            />
                            {errors.categoryId && <p className="text-xs text-destructive mt-1">{errors.categoryId.message}</p>}
                        </div>

                        {/* Name */}
                        <div>
                            <label className={labelClass}>Item Name <span className="text-destructive">*</span></label>
                            <Input {...register("name")} placeholder="e.g. Chicken Tikka" className={cn(errors.name && "border-destructive")} />
                            {errors.name && <p className="text-xs text-destructive mt-1">{errors.name.message}</p>}
                        </div>

                        {/* Price + Status */}
                        <div className="grid grid-cols-2 gap-3">
                            <div>
                                <label className={labelClass}>Base Price (Rs.) <span className="text-destructive">*</span></label>
                                <Input type="number" {...register("basePrice", { valueAsNumber: true })} placeholder="0" className={cn(errors.basePrice && "border-destructive")} />
                                {errors.basePrice && <p className="text-xs text-destructive mt-1">{errors.basePrice.message}</p>}
                            </div>
                            <div>
                                <label className={labelClass}>Status</label>
                                <Controller
                                    control={control}
                                    name="status"
                                    render={({ field }) => (
                                        <Select value={field.value} onValueChange={(v) => v && field.onChange(v)}>
                                            <SelectTrigger className="w-full">
                                                <SelectValue>
                                                    {(value: string) => value.replace(/_/g, " ")}
                                                </SelectValue>
                                            </SelectTrigger>
                                            <SelectContent>
                                                {STATUS_OPTIONS.map((s) => (
                                                    <SelectItem key={s} value={s}>{s.replace(/_/g, " ")}</SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    )}
                                />
                            </div>
                        </div>

                        {/* Variants */}
                        <SectionTitle>Variants</SectionTitle>
                        <div className="space-y-2">
                            {variantFields.map((field, index) => (
                                <div key={field.id} className="flex items-center gap-2 p-3 border rounded-lg bg-muted/30">
                                    <Input
                                        {...register(`variants.${index}.name`)}
                                        placeholder="e.g. Half kg"
                                        className="flex-2"
                                    />
                                    <Input
                                        type="number"
                                        {...register(`variants.${index}.price`, { valueAsNumber: true })}
                                        placeholder="Price"
                                        className="flex-1"
                                    />
                                    <label className="flex items-center gap-1.5 text-xs shrink-0">
                                        <input type="checkbox" {...register(`variants.${index}.isDefault`)} className="w-3.5 h-3.5" style={{ accentColor: "var(--primary)" }} />
                                        Default
                                    </label>
                                    <button type="button" onClick={() => removeVariant(index)} className="p-1.5 rounded hover:bg-red-50 text-muted-foreground hover:text-red-600 transition-colors shrink-0">
                                        <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                </div>
                            ))}
                            <button
                                type="button"
                                onClick={() => appendVariant({ name: "", price: 0, isDefault: false, isAvailable: true })}
                                className="flex items-center gap-1.5 text-xs font-medium text-primary hover:text-primary/80 transition-colors"
                            >
                                <Plus className="w-3.5 h-3.5" />
                                Add Variant
                            </button>
                        </div>

                        {/* Modifier Groups */}
                        <SectionTitle>Modifier Groups</SectionTitle>
                        <div className="space-y-3">
                            {modifierFields.map((field, groupIndex) => (
                                <div key={field.id} className="border rounded-xl p-4 space-y-3 bg-muted/20">
                                    <div className="flex items-center gap-2">
                                        <Input
                                            {...register(`modifierGroups.${groupIndex}.name`)}
                                            placeholder="e.g. Oil Preference"
                                            className="flex-1"
                                        />
                                        {errors.modifierGroups?.[groupIndex]?.name && (
                                            <p className="text-xs text-destructive mt-1">
                                                {errors.modifierGroups[groupIndex]?.name?.message}
                                            </p>
                                        )}
                                        <label className="flex items-center gap-1.5 text-xs shrink-0">
                                            <input type="checkbox" {...register(`modifierGroups.${groupIndex}.isRequired`)} className="w-3.5 h-3.5" style={{ accentColor: "var(--primary)" }} />
                                            Required
                                        </label>
                                        <button type="button" onClick={() => removeModifier(groupIndex)} className="p-1.5 rounded hover:bg-red-50 text-muted-foreground hover:text-red-600 transition-colors shrink-0">
                                            <Trash2 className="w-3.5 h-3.5" />
                                        </button>
                                    </div>
                                    <div className="flex gap-3">
                                        <div className="flex-1">
                                            <label className={labelClass}>Min Selections</label>
                                            <Input type="number" {...register(`modifierGroups.${groupIndex}.minSelections`, { valueAsNumber: true })} />
                                        </div>
                                        <div className="flex-1">
                                            <label className={labelClass}>Max Selections</label>
                                            <Input type="number" {...register(`modifierGroups.${groupIndex}.maxSelections`, { valueAsNumber: true })} />
                                        </div>
                                    </div>
                                    <ModifierOptions control={control} register={register} errors={errors} groupIndex={groupIndex} />
                                </div>
                            ))}
                            <button
                                type="button"
                                onClick={() => appendModifier({ name: "", isRequired: false, minSelections: 0, maxSelections: 1, options: [{ name: "", priceAdjustment: 0, isDefault: false, isAvailable: true }] })}
                                className="flex items-center gap-1.5 text-xs font-medium text-primary hover:text-primary/80 transition-colors"
                            >
                                <Plus className="w-3.5 h-3.5" />
                                Add Modifier Group
                            </button>
                        </div>

                    </form>
                </div>

                {/* Footer */}
                <div className="shrink-0 flex items-center justify-end gap-3 px-6 py-4 border-t border-border bg-card">
                    <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium rounded-lg border hover:bg-muted transition-colors">
                        Cancel
                    </button>
                    <button
                        type="submit"
                        form="item-form"
                        disabled={isLoading}
                        className="px-4 py-2 text-sm font-medium rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 transition-colors flex items-center gap-2"
                    >
                        {isLoading && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                        {isEdit ? "Save Changes" : "Add Item"}
                    </button>
                </div>
            </div>
        </div>
    );
}

// ─── Modifier Options ─────────────────────────────────────────────────────────

function ModifierOptions({
    control,
    register,
    errors,
    groupIndex,
}: {
    control: Control<ItemFormValues>;
    register: UseFormRegister<ItemFormValues>;
    errors: FieldErrors<ItemFormValues>;
    groupIndex: number;
}) {
    const { fields, append, remove } = useFieldArray({
        control,
        name: `modifierGroups.${groupIndex}.options`,
    });

    return (
        <div className="space-y-2">
            <label className={labelClass}>Options</label>
            {fields.map((field, optIndex) => (
                <div key={field.id} className="flex items-center gap-2">
                    <Input
                        {...register(`modifierGroups.${groupIndex}.options.${optIndex}.name`)}
                        placeholder="e.g. Desi Ghee"
                        className="flex-2"
                    />
                    {errors.modifierGroups?.[groupIndex]?.options?.[optIndex]?.name && (
                        <p className="text-xs text-destructive mt-1">
                            {errors.modifierGroups[groupIndex]?.options?.[optIndex]?.name?.message}
                        </p>
                    )}
                    <Input
                        type="number"
                        {...register(`modifierGroups.${groupIndex}.options.${optIndex}.priceAdjustment`, { valueAsNumber: true })}
                        placeholder="+0"
                        className="flex-1"
                    />
                    <label className="flex items-center gap-1.5 text-xs shrink-0">
                        <input type="checkbox" {...register(`modifierGroups.${groupIndex}.options.${optIndex}.isDefault`)} className="w-3.5 h-3.5" style={{ accentColor: "var(--primary)" }} />
                        Default
                    </label>
                    <button type="button" onClick={() => remove(optIndex)} className="p-1.5 rounded hover:bg-red-50 text-muted-foreground hover:text-red-600 transition-colors shrink-0">
                        <Trash2 className="w-3.5 h-3.5" />
                    </button>
                </div>
            ))}
            <button
                type="button"
                onClick={() => append({ name: "", priceAdjustment: 0, isDefault: false, isAvailable: true })}
                className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
            >
                <Plus className="w-3 h-3" />
                Add Option
            </button>
        </div>
    );
}