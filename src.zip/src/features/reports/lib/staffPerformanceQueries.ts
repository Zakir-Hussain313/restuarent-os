import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq, and, gte, lt, sql } from "drizzle-orm";

export interface StaffPerformanceRow {
  staffId: string | null;
  name: string;
  isDeleted: boolean;
  revenue: number;
  orderCount: number;
  averageOrderValue: number;
}

export async function getStaffPerformance(
  tenantId: string,
  branchId: string,
  start: Date,
  end: Date
): Promise<StaffPerformanceRow[]> {
  // orders.staffName is a persisted snapshot written at order-creation time
  // (see orders.staffId's onDelete: "set null" comment in schema), so a
  // deleted staff member's past orders still carry their name here — no
  // join to the live `staff` table needed, and nothing to silently drop.
  const rows = await db
    .select({
      staffId: orders.staffId,
      staffName: orders.staffName,
      revenue: sql<number>`coalesce(sum(${orders.total}), 0)`,
      orderCount: sql<number>`count(*)`,
    })
    .from(orders)
    .where(
      and(
        eq(orders.tenantId, tenantId),
        eq(orders.branchId, branchId),
        eq(orders.status, "completed"),
        gte(orders.completedAt, start),
        lt(orders.completedAt, end)
      )
    )
    // Group by staffId AND staffName — multiple deleted staff all share
    // staffId = null, so grouping by staffId alone would collapse them
    // into a single "Deleted staff" row.
    .groupBy(orders.staffId, orders.staffName)
    .orderBy(sql`coalesce(sum(${orders.total}), 0) desc`);

  return rows.map((r) => {
    const revenue = Number(r.revenue);
    const orderCount = Number(r.orderCount);
    return {
      staffId: r.staffId,
      name: r.staffName ?? "Unknown",
      isDeleted: !r.staffId,
      revenue,
      orderCount,
      averageOrderValue: orderCount > 0 ? Math.round(revenue / orderCount) : 0,
    };
  });
}