CREATE TYPE "public"."table_seating_type" AS ENUM('chairs', 'sofa');--> statement-breakpoint
ALTER TABLE "restaurant_tables" ADD COLUMN "seating_type" "table_seating_type" DEFAULT 'chairs' NOT NULL;--> statement-breakpoint
ALTER TABLE "restaurant_tables" ADD COLUMN "chair_layout" jsonb;