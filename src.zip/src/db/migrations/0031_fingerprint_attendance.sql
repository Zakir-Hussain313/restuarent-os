CREATE TYPE "public"."attendance_source" AS ENUM('manual', 'self_service', 'biometric');--> statement-breakpoint
CREATE TYPE "public"."device_type" AS ENUM('browser', 'fingerprint_scanner');--> statement-breakpoint
CREATE TABLE "staff_biometric_enrollments" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"tenant_id" uuid NOT NULL,
	"staff_id" uuid NOT NULL,
	"branch_device_id" uuid NOT NULL,
	"external_user_id" text NOT NULL,
	"created_by" uuid NOT NULL,
	"enrolled_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "staff_biometric_enrollments_device_external_user_unique" UNIQUE("branch_device_id","external_user_id")
);
--> statement-breakpoint
ALTER TABLE "branch_devices" ALTER COLUMN "device_token" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "attendance" ADD COLUMN "source" "attendance_source" DEFAULT 'manual' NOT NULL;--> statement-breakpoint
ALTER TABLE "branch_devices" ADD COLUMN "device_type" "device_type" DEFAULT 'browser' NOT NULL;--> statement-breakpoint
ALTER TABLE "branch_devices" ADD COLUMN "external_device_id" text;--> statement-breakpoint
ALTER TABLE "staff_biometric_enrollments" ADD CONSTRAINT "staff_biometric_enrollments_tenant_id_tenants_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "staff_biometric_enrollments" ADD CONSTRAINT "staff_biometric_enrollments_staff_id_staff_id_fk" FOREIGN KEY ("staff_id") REFERENCES "public"."staff"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "staff_biometric_enrollments" ADD CONSTRAINT "staff_biometric_enrollments_branch_device_id_branch_devices_id_fk" FOREIGN KEY ("branch_device_id") REFERENCES "public"."branch_devices"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "staff_biometric_enrollments" ADD CONSTRAINT "staff_biometric_enrollments_created_by_staff_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."staff"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "staff_biometric_enrollments_tenant_id_idx" ON "staff_biometric_enrollments" USING btree ("tenant_id");--> statement-breakpoint
CREATE INDEX "staff_biometric_enrollments_staff_id_idx" ON "staff_biometric_enrollments" USING btree ("staff_id");--> statement-breakpoint
CREATE INDEX "staff_biometric_enrollments_device_id_idx" ON "staff_biometric_enrollments" USING btree ("branch_device_id");--> statement-breakpoint
CREATE INDEX "branch_devices_external_id_idx" ON "branch_devices" USING btree ("external_device_id");