ALTER TABLE "stock_movements" ADD COLUMN "stock_before_movement" numeric(12, 3);--> statement-breakpoint
ALTER TABLE "stock_movements" ADD COLUMN "avg_cost_before_movement" integer;