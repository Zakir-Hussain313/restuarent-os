CREATE INDEX "staff_tenant_id_idx" ON "staff" USING btree ("tenant_id");--> statement-breakpoint
CREATE INDEX "staff_branch_id_idx" ON "staff" USING btree ("branch_id");--> statement-breakpoint
CREATE INDEX "menu_categories_branch_id_idx" ON "menu_categories" USING btree ("branch_id");--> statement-breakpoint
CREATE INDEX "menu_item_variants_menu_item_id_idx" ON "menu_item_variants" USING btree ("menu_item_id");--> statement-breakpoint
CREATE INDEX "menu_items_branch_id_idx" ON "menu_items" USING btree ("branch_id");--> statement-breakpoint
CREATE INDEX "menu_items_category_id_idx" ON "menu_items" USING btree ("category_id");--> statement-breakpoint
CREATE INDEX "modifier_groups_menu_item_id_idx" ON "modifier_groups" USING btree ("menu_item_id");--> statement-breakpoint
CREATE INDEX "modifier_options_modifier_group_id_idx" ON "modifier_options" USING btree ("modifier_group_id");--> statement-breakpoint
CREATE INDEX "restaurant_tables_branch_id_idx" ON "restaurant_tables" USING btree ("branch_id");--> statement-breakpoint
CREATE INDEX "restaurant_tables_section_id_idx" ON "restaurant_tables" USING btree ("section_id");--> statement-breakpoint
CREATE INDEX "table_sections_branch_id_idx" ON "table_sections" USING btree ("branch_id");