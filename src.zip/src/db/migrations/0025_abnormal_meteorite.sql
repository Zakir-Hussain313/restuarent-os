ALTER TABLE "attendance" DROP CONSTRAINT "attendance_staff_id_staff_id_fk";
--> statement-breakpoint
ALTER TABLE "attendance" DROP CONSTRAINT "attendance_logged_by_staff_id_fk";
--> statement-breakpoint
ALTER TABLE "coupons" DROP CONSTRAINT "coupons_created_by_staff_id_fk";
--> statement-breakpoint
ALTER TABLE "order_discounts" DROP CONSTRAINT "order_discounts_applied_by_staff_id_fk";
--> statement-breakpoint
ALTER TABLE "orders" DROP CONSTRAINT "orders_staff_id_staff_id_fk";
--> statement-breakpoint
ALTER TABLE "payments" DROP CONSTRAINT "payments_processed_by_staff_id_fk";
--> statement-breakpoint
ALTER TABLE "attendance" ALTER COLUMN "staff_id" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "attendance" ALTER COLUMN "logged_by" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "coupons" ALTER COLUMN "created_by" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "order_discounts" ALTER COLUMN "applied_by" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "payments" ALTER COLUMN "processed_by" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "attendance" ADD COLUMN "staff_name" text;--> statement-breakpoint
ALTER TABLE "attendance" ADD COLUMN "staff_id_snapshot" text;--> statement-breakpoint
ALTER TABLE "attendance" ADD COLUMN "logged_by_name" text;--> statement-breakpoint
ALTER TABLE "coupons" ADD COLUMN "created_by_name" text;--> statement-breakpoint
ALTER TABLE "order_discounts" ADD COLUMN "applied_by_name" text;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "staff_name" text;--> statement-breakpoint
ALTER TABLE "payments" ADD COLUMN "processed_by_name" text;--> statement-breakpoint
ALTER TABLE "attendance" ADD CONSTRAINT "attendance_staff_id_staff_id_fk" FOREIGN KEY ("staff_id") REFERENCES "public"."staff"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "attendance" ADD CONSTRAINT "attendance_logged_by_staff_id_fk" FOREIGN KEY ("logged_by") REFERENCES "public"."staff"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "coupons" ADD CONSTRAINT "coupons_created_by_staff_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."staff"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "order_discounts" ADD CONSTRAINT "order_discounts_applied_by_staff_id_fk" FOREIGN KEY ("applied_by") REFERENCES "public"."staff"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "orders" ADD CONSTRAINT "orders_staff_id_staff_id_fk" FOREIGN KEY ("staff_id") REFERENCES "public"."staff"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "payments" ADD CONSTRAINT "payments_processed_by_staff_id_fk" FOREIGN KEY ("processed_by") REFERENCES "public"."staff"("id") ON DELETE set null ON UPDATE no action;