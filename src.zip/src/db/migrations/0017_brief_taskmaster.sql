CREATE TABLE "coupon_branch_allocations" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"tenant_id" uuid NOT NULL,
	"coupon_id" uuid NOT NULL,
	"branch_id" uuid NOT NULL,
	"allocated_uses" integer NOT NULL,
	"used_count" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "coupons" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"tenant_id" uuid NOT NULL,
	"name" text NOT NULL,
	"description" text,
	"discount_type" "discount_type" NOT NULL,
	"discount_value" integer NOT NULL,
	"valid_from" timestamp with time zone,
	"valid_to" timestamp with time zone,
	"max_uses" integer,
	"uses_count" integer DEFAULT 0 NOT NULL,
	"branch_ids" uuid[],
	"menu_item_ids" uuid[],
	"category_ids" uuid[],
	"is_active" boolean DEFAULT true NOT NULL,
	"created_by" uuid NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "reservation_counters" (
	"branch_id" uuid PRIMARY KEY NOT NULL,
	"tenant_id" uuid NOT NULL,
	"next_number" integer DEFAULT 1 NOT NULL
);
--> statement-breakpoint
CREATE TABLE "push_subscriptions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"staff_id" uuid NOT NULL,
	"endpoint" text NOT NULL,
	"p256dh" text NOT NULL,
	"auth" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "push_subscriptions_staff_endpoint_unique" UNIQUE("staff_id","endpoint")
);
--> statement-breakpoint
CREATE TABLE "notification_reads" (
	"notification_id" uuid NOT NULL,
	"staff_id" uuid NOT NULL,
	"read_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "notification_reads_notification_id_staff_id_pk" PRIMARY KEY("notification_id","staff_id")
);
--> statement-breakpoint
CREATE TABLE "notifications" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"tenant_id" uuid NOT NULL,
	"branch_id" uuid NOT NULL,
	"type" text NOT NULL,
	"title" text NOT NULL,
	"message" text NOT NULL,
	"resource_type" text,
	"resource_id" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
DROP INDEX "orders_tenant_created_at_idx";--> statement-breakpoint
ALTER TABLE "branches" ADD COLUMN "city" text NOT NULL;--> statement-breakpoint
ALTER TABLE "branches" ADD COLUMN "operating_hours" jsonb;--> statement-breakpoint
ALTER TABLE "table_reservations" ADD COLUMN "reservation_number" text NOT NULL;--> statement-breakpoint
ALTER TABLE "table_reservations" ADD COLUMN "reservation_code" text NOT NULL;--> statement-breakpoint
ALTER TABLE "table_reservations" ADD COLUMN "start_time" timestamp with time zone NOT NULL;--> statement-breakpoint
ALTER TABLE "table_reservations" ADD COLUMN "duration_minutes" integer DEFAULT 90 NOT NULL;--> statement-breakpoint
ALTER TABLE "order_discounts" ADD COLUMN "coupon_id" uuid;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "idempotency_key" text;--> statement-breakpoint
ALTER TABLE "orders" ADD COLUMN "was_offline_order" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "coupon_branch_allocations" ADD CONSTRAINT "coupon_branch_allocations_tenant_id_tenants_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "coupon_branch_allocations" ADD CONSTRAINT "coupon_branch_allocations_coupon_id_coupons_id_fk" FOREIGN KEY ("coupon_id") REFERENCES "public"."coupons"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "coupon_branch_allocations" ADD CONSTRAINT "coupon_branch_allocations_branch_id_branches_id_fk" FOREIGN KEY ("branch_id") REFERENCES "public"."branches"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "coupons" ADD CONSTRAINT "coupons_tenant_id_tenants_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "coupons" ADD CONSTRAINT "coupons_created_by_staff_id_fk" FOREIGN KEY ("created_by") REFERENCES "public"."staff"("id") ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "reservation_counters" ADD CONSTRAINT "reservation_counters_branch_id_branches_id_fk" FOREIGN KEY ("branch_id") REFERENCES "public"."branches"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "reservation_counters" ADD CONSTRAINT "reservation_counters_tenant_id_tenants_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "push_subscriptions" ADD CONSTRAINT "push_subscriptions_staff_id_staff_id_fk" FOREIGN KEY ("staff_id") REFERENCES "public"."staff"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notification_reads" ADD CONSTRAINT "notification_reads_notification_id_notifications_id_fk" FOREIGN KEY ("notification_id") REFERENCES "public"."notifications"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notification_reads" ADD CONSTRAINT "notification_reads_staff_id_staff_id_fk" FOREIGN KEY ("staff_id") REFERENCES "public"."staff"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_tenant_id_tenants_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_branch_id_branches_id_fk" FOREIGN KEY ("branch_id") REFERENCES "public"."branches"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "coupon_branch_allocations_tenant_id_idx" ON "coupon_branch_allocations" USING btree ("tenant_id");--> statement-breakpoint
CREATE INDEX "coupon_branch_allocations_coupon_id_idx" ON "coupon_branch_allocations" USING btree ("coupon_id");--> statement-breakpoint
CREATE INDEX "coupon_branch_allocations_branch_id_idx" ON "coupon_branch_allocations" USING btree ("branch_id");--> statement-breakpoint
CREATE UNIQUE INDEX "coupon_branch_allocations_coupon_branch_udx" ON "coupon_branch_allocations" USING btree ("coupon_id","branch_id");--> statement-breakpoint
CREATE INDEX "coupons_tenant_id_idx" ON "coupons" USING btree ("tenant_id");--> statement-breakpoint
CREATE INDEX "push_subscriptions_staff_id_idx" ON "push_subscriptions" USING btree ("staff_id");--> statement-breakpoint
CREATE INDEX "notification_reads_staff_id_idx" ON "notification_reads" USING btree ("staff_id");--> statement-breakpoint
CREATE INDEX "notifications_branch_id_idx" ON "notifications" USING btree ("branch_id");--> statement-breakpoint
CREATE INDEX "notifications_tenant_id_idx" ON "notifications" USING btree ("tenant_id");--> statement-breakpoint
CREATE INDEX "notifications_branch_created_at_idx" ON "notifications" USING btree ("branch_id","created_at");--> statement-breakpoint
ALTER TABLE "order_discounts" ADD CONSTRAINT "order_discounts_coupon_id_coupons_id_fk" FOREIGN KEY ("coupon_id") REFERENCES "public"."coupons"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "table_reservations_start_time_idx" ON "table_reservations" USING btree ("start_time");--> statement-breakpoint
CREATE INDEX "order_discounts_coupon_id_idx" ON "order_discounts" USING btree ("coupon_id");--> statement-breakpoint
CREATE INDEX "orders_tenant_completed_at_idx" ON "orders" USING btree ("tenant_id","completed_at");--> statement-breakpoint
CREATE UNIQUE INDEX "orders_idempotency_key_udx" ON "orders" USING btree ("idempotency_key");--> statement-breakpoint
ALTER TABLE "tenant_settings" DROP COLUMN "operating_hours";