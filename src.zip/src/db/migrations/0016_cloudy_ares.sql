CREATE TYPE "public"."reservation_status" AS ENUM('pending', 'confirmed', 'seated', 'cancelled', 'no_show');--> statement-breakpoint
CREATE TABLE "table_reservations" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"tenant_id" uuid NOT NULL,
	"branch_id" uuid NOT NULL,
	"table_id" uuid NOT NULL,
	"customer_name" text,
	"customer_phone" text NOT NULL,
	"party_size" integer NOT NULL,
	"notes" text,
	"status" "reservation_status" DEFAULT 'pending' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "table_reservations" ADD CONSTRAINT "table_reservations_tenant_id_tenants_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "table_reservations" ADD CONSTRAINT "table_reservations_branch_id_branches_id_fk" FOREIGN KEY ("branch_id") REFERENCES "public"."branches"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "table_reservations" ADD CONSTRAINT "table_reservations_table_id_restaurant_tables_id_fk" FOREIGN KEY ("table_id") REFERENCES "public"."restaurant_tables"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "table_reservations_tenant_id_idx" ON "table_reservations" USING btree ("tenant_id");--> statement-breakpoint
CREATE INDEX "table_reservations_branch_id_idx" ON "table_reservations" USING btree ("branch_id");--> statement-breakpoint
CREATE INDEX "table_reservations_table_id_idx" ON "table_reservations" USING btree ("table_id");--> statement-breakpoint
CREATE INDEX "table_reservations_status_idx" ON "table_reservations" USING btree ("status");--> statement-breakpoint
CREATE INDEX "table_reservations_table_status_idx" ON "table_reservations" USING btree ("table_id","status");