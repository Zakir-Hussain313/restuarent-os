CREATE TYPE "public"."device_status" AS ENUM('pending', 'approved');--> statement-breakpoint
CREATE TABLE "branch_devices" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"tenant_id" uuid NOT NULL,
	"branch_id" uuid NOT NULL,
	"device_token" text NOT NULL,
	"status" "device_status" DEFAULT 'pending' NOT NULL,
	"label" text,
	"requested_by" uuid NOT NULL,
	"approved_by" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"approved_at" timestamp with time zone
);
--> statement-breakpoint
ALTER TABLE "branch_devices" ADD CONSTRAINT "branch_devices_tenant_id_tenants_id_fk" FOREIGN KEY ("tenant_id") REFERENCES "public"."tenants"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "branch_devices" ADD CONSTRAINT "branch_devices_branch_id_branches_id_fk" FOREIGN KEY ("branch_id") REFERENCES "public"."branches"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "branch_devices" ADD CONSTRAINT "branch_devices_requested_by_staff_id_fk" FOREIGN KEY ("requested_by") REFERENCES "public"."staff"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "branch_devices" ADD CONSTRAINT "branch_devices_approved_by_staff_id_fk" FOREIGN KEY ("approved_by") REFERENCES "public"."staff"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "branch_devices_branch_id_idx" ON "branch_devices" USING btree ("branch_id");--> statement-breakpoint
CREATE INDEX "branch_devices_tenant_id_idx" ON "branch_devices" USING btree ("tenant_id");--> statement-breakpoint
CREATE INDEX "branch_devices_token_idx" ON "branch_devices" USING btree ("device_token");