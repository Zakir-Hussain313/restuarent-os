CREATE TABLE "notification_clears" (
	"staff_id" uuid PRIMARY KEY NOT NULL,
	"branch_id" uuid NOT NULL,
	"cleared_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "notification_clears" ADD CONSTRAINT "notification_clears_staff_id_staff_id_fk" FOREIGN KEY ("staff_id") REFERENCES "public"."staff"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "notification_clears" ADD CONSTRAINT "notification_clears_branch_id_branches_id_fk" FOREIGN KEY ("branch_id") REFERENCES "public"."branches"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "notification_clears_branch_id_idx" ON "notification_clears" USING btree ("branch_id");