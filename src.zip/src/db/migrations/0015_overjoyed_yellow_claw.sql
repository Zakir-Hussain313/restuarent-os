ALTER TYPE "public"."table_status" ADD VALUE 'out_of_service';--> statement-breakpoint
ALTER TABLE "restaurant_tables" ADD COLUMN "notes" text;