ALTER TYPE "public"."delivery_status" ADD VALUE 'unassigned' BEFORE 'assigned';--> statement-breakpoint
ALTER TABLE "staff" ADD COLUMN "is_available" boolean DEFAULT false NOT NULL;